importScripts("https://www.gstatic.com/firebasejs/9.0.0/firebase-app-compat.js");
importScripts("https://www.gstatic.com/firebasejs/9.0.0/firebase-messaging-compat.js");

// Initialize Firebase with your config
const firebaseConfig = {
  apiKey: "AIzaSyCZ_q9jqT5ifGVt9fZ5Np3g7ytD1rWWLqM",
  authDomain: "pursuit-notification.firebaseapp.com",
  projectId: "pursuit-notification",
  storageBucket: "pursuit-notification.firebasestorage.app",
  messagingSenderId: "1005565907411",
  appId: "1:1005565907411:web:25daeb02296c3215dbdf26",
  measurementId: "G-BM4ZVBJBR2",
};

firebase.initializeApp(firebaseConfig);

const messaging = firebase.messaging();

messaging.onBackgroundMessage((payload) => {
  console.log("Received background message: ", payload);
  const notificationTitle = payload.notification.title;
  const notificationOptions = {
    body: payload.notification.body,
    icon: payload.notification.icon,
  };

  self.registration.showNotification(notificationTitle, notificationOptions);
});