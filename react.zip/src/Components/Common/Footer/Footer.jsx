import React from "react";
import styles from "./Footer.module.css"; // Import the CSS module

function Footer() {
    return (
        <>
            <footer className={styles.footer}>
                <div className={styles.container}>
                    <span className={styles.content}>
                        Copyright &copy; 2024 Whiteboard. All rights reserved.
                    </span>
                </div>
            </footer>
        </>
    );
}

export default Footer;
