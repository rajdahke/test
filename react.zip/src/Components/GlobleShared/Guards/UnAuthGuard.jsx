import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useBehaviorSubject } from '../BehaviorSubject/BehaviorSubject';

const UnAuthGuard = ({ component }) => {
    const [status, setStatus] = useState(false);
    const { isLoginUser } = useBehaviorSubject();
    const navigate = useNavigate();

    useEffect(() => {
        checkToken();
    }, [component]);

    const checkToken = async () => {
        try {
            let user = await isLoginUser;
            // if (!user) {
            if (!(user?.isUser) && !(user?.isGuest)) {
                localStorage.removeItem("token");
                // navigate(`/sign-in`);
            } else {
                navigate(`/member/dashboard`);
            }
            setStatus(true);
        } catch (error) {
            navigate(`/member/dashboard`);
        }
    }

    return status ? <React.Fragment>{component}</React.Fragment> : <React.Fragment></React.Fragment>;
}

export default UnAuthGuard;