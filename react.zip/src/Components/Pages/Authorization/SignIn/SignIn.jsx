import { Link, useNavigate } from "react-router-dom";
import classes from "./SignIn.module.css"
import ApiService from "../../../../Services/APIService";
import { useBehaviorSubject } from "../../../GlobleShared/BehaviorSubject/BehaviorSubject";
import { useState,useEffect} from "react";
import { toast } from "react-toastify";
import loginFace from "../../../../Assets/Images/signin-page-img.png";
import unionLogo from "../../../../Assets/Images/msm-unify-logo.svg";
import google from "../../../../Assets/Logo/new_google-icon.svg";
import facebook from "../../../../Assets/Logo/new_facebook-icon.svg";
import apple from "../../../../Assets/Logo/new_apple-icon.svg";
import Loader from "../../../GlobleShared/Loader/Loader";
import counseling from '../../../../Assets/Images/Free-counseling.png';
import countryCourse from '../../../../Assets/Images/Country-course.png';
import standardized from '../../../../Assets/Images/Standardized.png';
import application from '../../../../Assets/Images/Application.png';
import { googleLogout, useGoogleLogin } from "@react-oauth/google";
import axios from "axios";
import ProfileService from "../../../../Services/ProfileService";
import useLocalStorage from "../../../GlobleShared/CustomHooks/useLocalStorage";
import { generateToken } from "../../../PushNotification/firebase";
import loginImg from "../../../../Assets/Images/login-img.png";

const SignIn = () => {
  const [isLoading, setisLoading] = useState(false);
  const { setisLoginUser } = useBehaviorSubject();
  const navigate = useNavigate();
  const [visible, setVisible] = useState(false);
  const [passwordType, setPasswordType] = useState("password");
    const [rowData, setRowData] = useState();
  const [userDetail] = useLocalStorage('userDetail');
  const [studentId, setStudentId] = useState();
  const [user, setUser] = useState(null);

  //  state for userDetails
  const [form, setForm] = useState({
    email: "",
    "ipAddress": "0.0.0.0",
    "loginType": 1,
    password: "",
  });

  const [formErrors, setFormErrors] = useState({
    email: null,
    password: null,
  });

  const changeHandler = (e) => {
    const { name, value } = e.target;

    // Initialize sanitizedValue
    let sanitizedValue = value;

    // Sanitize email only if it's the email field
    if (name === 'email' && value) {
      sanitizedValue = value.replace(/\s/g, ''); // Remove spaces from email
    }

    setForm((prevForm) => ({
      ...prevForm,
      [name]: sanitizedValue,
    }));

    if (formErrors[name] !== undefined) {
      const errorMsg = validateField(name, sanitizedValue);
      setFormErrors((prevFormErrors) => ({
        ...prevFormErrors,
        [name]: errorMsg,
      }));
    }
  };

  const validateField = (name, value) => {
    let errorMsg = null;
    switch (name) {
      case "email":
        if (!value) errorMsg = "Please enter email";
        else if (
          !/^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@(([[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/.test(
            value
          )
        )
          errorMsg = "Please enter a valid email";
        break;
      case "password":
        if (!value) errorMsg = "Please enter password";
        break;
      default:
        break;
    }
    return errorMsg;
  };

  const validateForm = (form) => {
    const errorObj = {};
    Object.keys(form).forEach((key) => {
      const msg = validateField(key, form[key]);
      if (msg) errorObj[key] = msg;
    });
    return errorObj;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const errors = validateForm(form);
    setFormErrors(errors);
    if (Object.keys(errors).length === 0) {
      setisLoading(true);
      ApiService.signInV1(form)
        .then((res) => {
          localStorage.setItem("token", res?.token);
          localStorage.setItem("userDetail", JSON.stringify(res?.internalUserResponse));
          // setisLoginUser(true);
          setisLoginUser({ isUser: true, isGuest: false });
          generateToken();
          toast.success(res?.message);
          setisLoading(false);
          navigate("/member/dashboard");
        })
        .catch((error) => {
          setisLoading(false);
          toast.error(error?.message);
        });
    }
    console.log("Data:", form);
  };

  const viewPass = () => {
    setVisible(!visible);
    setPasswordType(passwordType === "password" ? "text" : "password");
  };

  const handleGuestLogin = () => {
    setisLoginUser({ isUser: false, isGuest: true });
    localStorage.setItem("userDetail", JSON.stringify({ isGuest: true }));
    navigate('/member/dashboard');
  };



  const login = useGoogleLogin({
    onSuccess: (codeResponse) => setUser(codeResponse),
    onError: (error) =>{},
  });


  const googleSign = (res) => {
    const { given_name, family_name, email, picture } = res.data;
    let request ={
      firstName: given_name,
      lastName: family_name,
      email: email,
    };

    setisLoading(true);

    ApiService.googleSignIn(request)
      .then((res) => {
        localStorage.setItem("token", res?.token);
        localStorage.setItem("userDetail", JSON.stringify(res?.internalUserResponse));
        console.log('res: ', res?.internalUserResponse);
        setStudentId(res?.internalUserResponse?.refId);
        setisLoginUser({ isUser: true, isGuest: false });
        setisLoading(false);
        // navigate("/member/dashboard");
        getAboutProfileInfo(res?.internalUserResponse?.refId)
      })
      .catch((error) => {
        setisLoading(false);
        toast.error(error?.message);
      });
    };

    const getAboutProfileInfo = (studentId) => {
      setisLoading(true);
      ProfileService.getAboutProfileInfo(studentId)
        .then((res) => {
         if(res?.DateOfBirth && res?.MobileNo && res?.Country)
         {
          navigate("/member/dashboard");
         }
         else
          {
            navigate("/member/profile?tab=About");
          }
        })
        .catch((error) => {
          console.log('error: ', error);
          setisLoading(false);
        });
    };


  // useEffect(() => {
  //   if (user) {
  //     axios
  //       .get(
  //         `https://www.googleapis.com/oauth2/v1/userinfo?access_token=${user.access_token}`,
  //         {
  //           headers: {
  //             Authorization: `Bearer ${user.access_token}`,
  //             Accept: "application/json",
  //           },
  //         }
  //       )
  //       .then((res) => {
  //           googleSign(res);
  //       })
  //       .catch((err) => console.log(err));
  //   }
  // }, [user]);

  useEffect(() => {
    if (user) {
      axios
        // .get(
        //   `https://accounts.google.com/o/oauth2/v1/userinfo?access_token=${user.access_token}`,
        //   {
        //     headers: {
        //       Authorization: `Bearer ${user.access_token}`,
        //       Accept: "application/json",
        //     },
        //   }
        // )
        .get(
          `https://www.googleapis.com/oauth2/v1/userinfo?access_token=${user.access_token}`,
          {
            headers: {
              Authorization: `Bearer ${user.access_token}`,
              Accept: "application/json",
            },
          }
        )
        .then((res) => {
            googleSign(res);
        })
        .catch((err) => console.log(err));
    }
  }, [user]);

  return (
    <>
      <div className={classes["login-section"]}>
        <div className={`${classes.row_hieght} row`}>
          <div className={`${classes.col_img} col-md-7`}>
            <div className={classes["left-block-header"]}>
              <div className="mt-3"><img className={classes["login-image"]} src={unionLogo} alt='' /></div>


              <div className={classes["sub-heading"]}>Unlock Your Future with MSM Unify!</div>
              <div className={classes["description"]}>
                Get expert support at every step — from free counseling to institutional admissions.
              </div>
            </div>

            <div className={classes["left-block-cards"]}>
              <img className={classes["left-img"]} src={loginImg} alt="" />
            </div>

          </div>
          <div className={`${classes['col-color']} col-md-5 p-0`}>
            <div className={classes["section-2"]}>
              <div className={classes["login-card"]}>
                <div className={classes["section-2_heading"]}>
                  <h1>Login</h1>
                  <div className={classes["h1_sub-heading"]}>Your ultimate guide to studying abroad.</div>
                </div>
                <div className={classes["section-2_form"]}>
                  <form>
                    <div className={classes["login-form-block"]}>

                      <div className={classes["block-1"]}>
                        <div className={classes["form-field"]}>
                          <div className={classes["mat-form-field"]}>
                            <input
                              placeholder=" "
                              onChange={changeHandler}
                              onBlur={changeHandler}
                              name="email"
                              value={form.email}
                              className={classes["mat-input"]}
                              type="text"
                              required
                            />
                            <label className={classes["mat-label"]}>Email*</label>
                            {formErrors.email && <span className="error-alert">{formErrors.email}</span>}
                          </div>
                        </div>
                        <div className={classes["form-field"]}>
                          <div className={classes["mat-form-field"]}>
                            <input
                              placeholder=" "
                              onChange={changeHandler}
                              onBlur={changeHandler}
                              name="password"
                              value={form.password}
                              className={classes["mat-input"]}
                              type={passwordType}
                              required
                            />
                            <label className={classes["mat-label"]}>Password</label>

                            {form.password && (
                              <div className={classes["icon-container"]}>
                                <span className="eyeicon" onClick={viewPass}>
                                  <i className={`fa ${visible ? "fa-eye" : "fa-eye-slash"}`} />
                                </span>
                              </div>
                            )}
                            {formErrors.password && <span className="error-alert">{formErrors.password}</span>}

                            <div className={classes["forgot-password-text"]}>
                              <Link to="/forgot-password">
                                Forgot Password?
                              </Link>
                            </div>
                          </div>
                        </div>
                        <div className={classes["login-form-btn"]}>
                          {/* <button onClick={handleSubmit} className={classes["login-btn"]}>Login</button>
                          <button className={classes["login-guest-btn"]}>Continue as guest</button> */}
                          <button disabled={isLoading} onClick={handleSubmit} className={classes["login-btn"]}>Login</button>
                          {/* <button className="secondary-button">Continue as guest</button> */}
                          <button onClick={handleGuestLogin} className={classes["login-guest-btn"]}>Continue as guest</button>
                        </div>
                      </div>

                      <div className={classes["block-2"]}>
                        <div className={classes["other-sign-in-option-text"]}>Or sign in with:</div>
                        <div className={classes["sign-in-option"]}>
                          <div className={classes["login-google-btn"]} onClick={() => login()}>
                            <img className={classes["img"]} src={google} alt="Google" />
                          </div>

                          <div className={classes["login-facebook-btn"]}>
                            <img className={classes["img"]} src={facebook} alt="Facebook" />
                          </div>

                          <div className={classes["login-apple-btn"]}>
                            <img className={classes["img"]} src={apple} alt="Apple" />
                          </div>
                        </div>
                      </div>

                      <div className={classes["block-3"]}>
                        <span>Don't have an account? </span>
                        <Link to="/sign-up">Sign up</Link>
                      </div>

                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div>{isLoading && <Loader />}</div>
      </div>
    </>
  )
}

export default SignIn