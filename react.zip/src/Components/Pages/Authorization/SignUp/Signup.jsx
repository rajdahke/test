import classes from "./SignUp.module.css";
import { Link, useNavigate } from "react-router-dom";
import ApiService from "../../../../Services/APIService.jsx";
import { useEffect, useState } from "react";
import Loader from "../../../GlobleShared/Loader/Loader.jsx";
import { useBehaviorSubject } from "../../../GlobleShared/BehaviorSubject/BehaviorSubject.jsx";
import { toast } from "react-toastify";
import leftImg from "../../../../Assets/Images/signin-page-img.png";
import union from "../../../../Assets/Images/msm-unify-logo.svg";
import dropDown from "../../../../Assets/Logo/drop-down_icon.svg";
import upperDrop from "../../../../Assets/Logo/uper-arrow-icon.svg";
import OTPInput from "react-otp-input";
import countryFlag from "../../../../Assets/Images/countryFlag.png";
import backArrow from "../../../../Assets/Logo/back-arrow.svg";
import 'flag-icons/css/flag-icons.min.css';
import { Col, Form, FormSelect, InputGroup, Row } from "react-bootstrap";
import Select from 'react-select';
import { components } from 'react-select';
import counseling from '../../../../Assets/Images/Free-counseling.png';
import countryCourse from '../../../../Assets/Images/Country-course.png';
import standardized from '../../../../Assets/Images/Standardized.png';
import application from '../../../../Assets/Images/Application.png';
import leftImage from '../../../../Assets/Images/right-image.png'

const inputStyle = {
  width: "48px",
  height: "64px",
  margin: "5px 10px 5px 0px",
  fontSize: "25px",
  borderRadius: 8,
  border: "0px solid #000",
  justifyContent: "center",
  fontWeight: "500",
  backgroundColor:'#F0ECEC'
};

const invalidOtpStyle = {
  width: "48px",
  height: "64px",
  margin: "5px 10px 5px 0px",
  fontSize: "25px",
  borderRadius: 8,
  border: "1px solid #000",
  justifyContent: "center",
  fontWeight: "500",
  color: "#000",
  backgroundColor:'#F0ECEC'
};

const CountryOption = ({ data, ...props }) => (
  <components.Option {...props}>
    <span className={`fi fi-${data.CShortName.toLowerCase()}`} style={{ marginRight: '8px' }}></span>
    {`+${data.CountryCode} - ${data.CountryName}`}
  </components.Option>
);

const SingleValue = ({ data, ...props }) => (
  <components.SingleValue {...props}>
    <span className={`fi fi-${data.CShortName.toLowerCase()}`} style={{ marginRight: '8px' }}></span>
    {`+${data.CountryCode}`}
  </components.SingleValue>
);

function SignUp() {
  const indianOtpCheck = process.env.REACT_APP_INDIA_OPT_CHECK;
  const [isLoading, setisLoading] = useState(false);
  const navigate = useNavigate();
  const [visible, setVisible] = useState(false);
  const [passwordType, setPasswordType] = useState("password");
  const [visibleConfirm, setVisibleConfirm] = useState(false);
  const [confirmPasswordType, setConfirmPasswordType] = useState("password");
  const [currentStep, setCurrentStep] = useState(1);
  const [otp, setOtp] = useState("");
  const [timeLeft, setTimeLeft] = useState(30);
  // State to hold password validation error
  const [passwordValidationErrors, setPasswordValidationErrors] = useState({});
  const [invalidOtp, setInvalidOtp] = useState();
  const [otpSubmitted, setOtpSubmitted] = useState(false);
  const [isCountryCodeOpen, setCountryCodeOpen] = useState(false);
  const [isGenderOpen, setGenderOpen] = useState(false);
  //  state for userDetails
  const GenderData = ["Male", "Female", "Others"];
  const [countryCode, setCountryCode] = useState([]);
  const { setisLoginUser } = useBehaviorSubject();
  // authorization logic to set bydefault the authorization is done by email
  const [authorizationMethod, setAuthorizationMethod] = useState("email");
  const [phoneNumber, setPhoneNumber] = useState("");
  const [otpCount, setOptCount] = useState();
  const [countryId, setCountryId]=useState(0)

 

const [otpMethod, setOtpMethod] = useState("");
const [otpDetails, setOtpDetails] = useState({});
const [otpEmailDetails, setOtpEmailDetails] = useState({});
const [verified, setVerified] = useState(false);
const [otpVerificationPossible, setOtpVerificationPossible] = useState(false);
const [otpType, setOtpType] = useState("email");
const [selectedCountry, setSelectedCountry] = useState(null);
const [dropdownOpen, setDropdownOpen] = useState(false);


  const handleFocus = (setOpen) => () => {
    setOpen(true);
  };

  const handleBlur = (setOpen) => () => {
    setOpen(false);
  };
  const [form, setForm] = useState({
    fname: "",
    lname: "",
    email: "",
    contact: "",
    countryCode: "",
    gender: "",
    dob: "",
    password: "",
    cpassword: "",
  });

  // state for errors
  const [formErrors, setFormErrors] = useState({
    fname: null,
    lname: null,
    email: null,
    contact: null,
    countryCode: null,
    gender: null,
    dob: null,
    password: null,
    cpassword: null,
    phoneNumber: null
  });

  // Handler for input changes

  const changeHandler = (e) => {
    const { name, value } = e.target;

    // Sanitize input based on field type
    const sanitizedValue = 
      (name === 'fname' || name === 'lname') 
        ? value.replace(/[^a-zA-Z]/g, '') // Remove non-letter characters for names
        : (name === 'email') 
        ? value.replace(/\s/g, '')
        : (name === 'contact') 
        ? value.replace(/\D/g, '') // Keep only digits for contact number
        : value;

    // Update form state
    setForm((prevForm) => ({
      ...prevForm,
      [name]: sanitizedValue,
    }));

    // Real-time validation for relevant fields
    if (['fname', 'lname', 'email', 'contact', 'dob'].includes(name)) {
      setFormErrors((prevFormErrors) => ({
        ...prevFormErrors,
        [name]: validateField(name, sanitizedValue),
      }));
    }

    // Validate password and confirm password fields
    if (name === 'password' || name === 'cpassword') {
      const validationErrors = validatePassword(
        name,
        name === 'password' ? sanitizedValue : form.password, // Update only the password field
        name === 'cpassword' ? sanitizedValue : form.cpassword // Update only the confirm password field
      );

      setFormErrors((prevFormErrors) => ({
        ...prevFormErrors,
        // [name]: name === 'password' ? validationErrors.passwordError : validationErrors.cpasswordError
        password: validationErrors.passwordError,
        cpassword: validationErrors.cpasswordError
      }));
      setPasswordValidationErrors(validationErrors);
    }

    // if (name === "countryCode") {
    //     if (value === "91") {
    //         setOtpVerificationPossible(true);
    //         console.log(otpVerificationPossible);
    //     } 
    //     else{
    //       setOtpVerificationPossible(false);
    //     }
    // }
  };

  // Function to validate individual fields
  const validateField = (name, value) => {
    let errorMsg = null;

    switch (name) {
      case 'fname':
      case 'lname':
        if (!value) errorMsg = `Please enter ${name === 'fname' ? 'first' : 'last'} name`;
        else if (/[^a-zA-Z]/.test(value)) errorMsg = 'Please enter a valid name';
        break;

      case 'contact':
      case 'phoneNumber':
        if (!value) errorMsg = 'Please enter contact number';
        else if ((value.replace(/\D/g, '').length) < 8 || (value.replace(/\D/g, '').length) > 10)
          errorMsg = 'Contact Number Should be between 8 and 10 digits';
        break;

      case 'email':
        if (!value) errorMsg = 'Please enter email';
        else if (
          !/^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@(([[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/.test(value)
        )
          errorMsg = 'Please enter a valid email';
        break;

      default:
        break;
    }

    return errorMsg;
  };

  // Function to validate password requirements {some optimization is remaining for this}
  const validatePassword = (name, password, cpassword) => {
    const errors = {
      passwordError: null,
      cpasswordError: null,
      minLength: password.length < 8,
      specialChar: !/[!@#$%^&*(),.?":{}|<>]/.test(password),
      number: !/\d/.test(password),
      uppercase: !/[A-Z]/.test(password),
    };

    switch (name) {
      case 'password':
        if (!password) errors.passwordError = 'Please enter a password';
        else if (cpassword && password !== cpassword) 
          errors.cpasswordError = 'Passwords do not match';
        break;

      case 'cpassword':
        if (!cpassword) errors.cpasswordError = 'Please enter confirm password';
        else if (password !== cpassword)
          errors.cpasswordError = 'Passwords do not match';
        break;

      default:
        break;
    }

  return errors;
};

  // Function to validate the entire form
  const validateForm = (form) => {
    const errorObj = {};
  
    Object.keys(form).forEach((key) => {
      const value = form[key];
      const errorMsg = validateField(key, value);
      
      if (key === 'password' || key === 'cpassword') {
        const passwordErrors = validatePassword(form.password, form.cpassword);
        if (passwordErrors.passwordError) errorObj.password = passwordErrors.passwordError;
        if (passwordErrors.cpasswordError) errorObj.cpassword = passwordErrors.cpasswordError;
      }
  
      if (errorMsg) {
        errorObj[key] = errorMsg;
      }
    });
  
    return errorObj;
  };

  const handleSubmit = () => {
    const errors = validateForm(form);
    setFormErrors(errors);
    if (Object.keys(errors).length === 0) {
      // setIsSubmit(true);
      const formData = {
        emailId: form.email,
        firstName: form.fname,
        lastName: form.lname,
        mobileNoCountryCode: form.countryCode,
        contactNumber: form.contact,
        gender: form.gender,
        dateOfBirth: form.dob,
        password: form.password,
        // profilePic: "",
        userLoginType: 1,
        countryId:countryId
      };

      setisLoading(true);
      ApiService.userRegistration(formData)
        .then((res) => {
          setisLoading(false);
          toast.success(res?.message);
          handleLogin();
        })
        .catch((error) => {
          setisLoading(false);
          toast.error(error?.message);
        });
    }
  };

  const handleLogin = () => {
    const errors = validateForm(form);
    setFormErrors(errors);
    if (Object.keys(errors).length === 0) {
      setisLoading(true);
      const formData = {
        email: form.email,
        "ipAddress": "0.0.0.0",
        "loginType": 1,
        password: form.password,
      }
      ApiService.signInV1(formData)
        .then((res) => {
          localStorage.setItem("token", res?.token);
          localStorage.setItem("userDetail", JSON.stringify(res?.internalUserResponse));
          setisLoginUser(true);
          setisLoading(false);
          navigate("/member/profile");
        })
        .catch((error) => {
          setisLoading(false);
          toast.error(error?.message);
        });
    }
  };

  const viewPass = () => {
    setVisible(!visible);
    setPasswordType(passwordType === "password" ? "text" : "password");
  };

  const viewConfirmPass = () => {
    setVisibleConfirm(!visibleConfirm);
    setConfirmPasswordType(
      confirmPasswordType === "password" ? "text" : "password"
    );
  };
  const checkEmailExistOrNOt = (email) => {
    setisLoading(true);
    ApiService.checkEmail(email)
      .then((res) => {
        if (res.errorCode === 200) {
          setCurrentStep(2);
        } else {
          toast.error(res?.errorMessage)
        }
        setisLoading(false);
      })
      .catch((error) => {
        setisLoading(false);
        toast.error(error?.message);
      });
  }
  const checkMobileNoExistOrNOt = (Mob) => {
    setisLoading(true);
    ApiService.checkMobileNo(Mob)
      .then((res) => {
        if (res.message === "") {
          setCurrentStep(3);
        } else {
          toast.error(res?.message)
        }
        setisLoading(false);
      })
      .catch((error) => {
        setisLoading(false);
        toast.error(error?.message);
      });
  }

  
  const handleNext = (e) => {
    e.preventDefault();
    if (currentStep === 1) {
      if (form.email && form.password && form.cpassword) {
        checkEmailExistOrNOt(form.email);
      }
    } else if (currentStep === 2) {
      if (form.fname && form.lname && form.contact && form.gender && form.dob) {
        checkMobileNoExistOrNOt(form.contact)
        // setCurrentStep(3);
        setPhoneNumber(form.contact);
      }
    }
    // just for checking next step
    else if (currentStep === 3) {
      if (form.email || phoneNumber) {
        console.log(authorizationMethod)
        otpValidationCount();
        if(otpCount>=4){
          toast.error("Limit exceeded, Try again after 24 hrs")
          setisLoading(false);
          return;
        }
        else{
        if (otpType === "phone") {
          setOtp("");
          sendAuthOtp(phoneNumber);
        }
        else if(otpType === "email"){
          setOtp("");
          sendEmailAuthOtp(form.email);
        }
        countdown();
        setCurrentStep(4);
      }
    }
    } else if (currentStep === 4 && otp?.length === 6) {
      if (otpType === "phone") {
        validateAuthOtp(otpDetails?.Details, otp);
      }
      else if (otpType === "email") {
        validateEmailAuthOtp(otpEmailDetails?.response, otp);
      }
    }
  };



  const handleBack = (e) => {
    e.preventDefault();
    if (currentStep === 2) {
      setCurrentStep(1);
    }
    if (currentStep === 3) {
     
      setCurrentStep(2);
    }
    if (currentStep === 4) {
      setTimeLeft("");
      setCurrentStep(3);
    }
  };

  // all authorizaiton logic here

  // changing the authorization as per the check on email or phone
  const handleChange = (e) => {
    const { name, value } = e.target;
    setAuthorizationMethod(e.target.value);
    if (value === 'email') {
      setOtpType("email"); // Store email if email is selected
    } else if (value === 'phone') {
      setOtpType("phone"); // Store phone number if phone is selected
    }
  };

  const getOtp = (otp) => {
    setInvalidOtp(false);
    setOtp(otp);
  };
  const backOnAuthentication = () => {
    setTimeLeft(0);
    setCurrentStep(currentStep - 1);
    setInvalidOtp(false);
    setOtp("");
  };


  const countdown = () => {
    let intervalId;
    let timeLeft = otpType === "email" ? 30 : 30;
    clearInterval(intervalId);
    setTimeLeft(timeLeft);
    intervalId = setInterval(() => {
      setTimeLeft((prevTime) => {
        if (prevTime <= 1) {
          clearInterval(intervalId);
          return 0;
        }
        return prevTime - 1;
      });
    }, 1000);
  };
  
  const getCountryCode = () => {
    setisLoading(true);
    ApiService.countryList()
      .then((res) => {
        setCountryCode(res);
        setisLoading(false);
      })
      .catch((error) => {
        setisLoading(false);
        toast.error(error?.message);
      });
  }
  useEffect(() => {
    getCountryCode()
  }, []);

  const getMaxDate = () => {
    const today = new Date();
    today.setDate(today.getDate() - 1);  // Set max date to yesterday
    return today.toISOString().split('T')[0];  // Format as yyyy-mm-dd
  };

  const handlePhoneNumber = (e) => {
    const { name, value } = e.target;
    const sanitizedValue = value.replace(/\D/g, '');
    setPhoneNumber(sanitizedValue);
    const errorMsg = validateField(name, sanitizedValue);
    setFormErrors((prevFormErrors) => ({
      ...prevFormErrors,
      [name]: errorMsg,
    }));
  }
  // for getting mobile otp details
  const sendAuthOtp = (number) => {
    setisLoading(true);
    ApiService.getMobOtp(number)
      .then((res) => {
        setisLoading(false);
        setOtpDetails(res.data);
        setVerified(false);

        countdown();
        setOtp("");
        setInvalidOtp(false);
        otpValidation();
      })
      .catch((error) => {
        setisLoading(false);
        toast.error(error?.message);
      });
  };

  
  // for validate mobile otp details
  const validateAuthOtp = (session, otp) => {
    setisLoading(true);
    ApiService.validateMobOtp(session, otp)
      .then((res) => {
        setisLoading(false);
        setVerified(true);
        otpSubmit();
        // countdown();
        setOtp("");
        setInvalidOtp(false);
        toast.success("OTP validated successfully.");
      })
      .catch((error) => {
        setisLoading(false);
        setInvalidOtp(true);
        toast.error(error?.Details);
      });
  };
  
  const toggleDropdown = () => setDropdownOpen(!dropdownOpen);

  const handleCountrySelect = (country) => {
    setSelectedCountry(country);
    if(indianOtpCheck){
        if (country.CountryCode === "91") {
            setOtpVerificationPossible(true);
        }else{
            setOtpVerificationPossible(false);
        }
    }else{
      setOtpVerificationPossible(true);
    }
    setDropdownOpen(false);
    setForm((prevForm) => ({
      ...prevForm,
      countryCode: country.CountryCode
    }));
    const countryIdValue =countryCode.find(item=> item?.CountryCode===country?.CountryCode)
    setCountryId(countryIdValue?.CountryId)
  };

  // for getting email otp details
  const sendEmailAuthOtp = (email) => {
    setisLoading(true);
    const data = {
      source: email,
      sourceType: "signup",
       sourceName: form.fname + " " + form.lname
    };
    ApiService.getEmailOtp(data)
      .then((res) => {
        setisLoading(false);
        setOtpEmailDetails(res);
        setVerified(false);

        countdown();
        setOtp("");
        setInvalidOtp(false);
        otpValidation();
      })
      .catch((error) => {
        setisLoading(false);
        toast.error(error?.message);
      });
  };
  const maskEmail = (email) => {
    const [localPart, domain] = email.split("@");
    
    if (localPart.length > 1) {
      const maskedLocalPart = localPart[0] + "*".repeat(localPart.length - 1);
      return `${maskedLocalPart}@${domain}`;
    }
    return email;
  };
  
  // for validating email otp
const validateEmailAuthOtp = (session, otp) => {
  
  const data = {
    sessionId: session,
    authCode: otp,
  };
  setisLoading(true);
  ApiService.validateEmailOtp(data)
    .then((res) => {
      setisLoading(false);
      setVerified(true);
      otpSubmit();
      // countdown();
      setOtp("");
      setInvalidOtp(false);
      toast.success("OTP validated successfully.");
    })
    .catch((error) => {
      setisLoading(false);
      setInvalidOtp(true);
      toast.error(error?.message);
    });
};

//valiadtion for otp count
const otpValidation = () => {
  ApiService.optValidation(form.email)
    .then((res) => {
     
    })
    .catch((error) => {
      toast.error(error?.message);
    });
};
const otpValidationCount = () => {
  ApiService.optValidationCount(form.email)
    .then((res) => {
     console.log("resCount",res)
     setOptCount(res)

    })
    .catch((error) => {
      toast.error(error?.message);
    });
};


  // for resend otp/
  const resendOtp = () => {
    setisLoading(true);
    otpValidationCount();
    if(otpCount>=4){
      toast.error("Limit exceeded, Try again after 24 hrs")
      setisLoading(false);
      return;
    }
    else{
    if (otpType === "phone") {
      setOtp("");
      sendAuthOtp(phoneNumber);
    }
    else if(otpType === "email"){
      setOtp("");
      sendEmailAuthOtp(form.email);
    }
    countdown();
    setInvalidOtp(false);
  }
  };

  const otpSubmit = () => {
    setInvalidOtp(false);
    setOtpSubmitted(true);
    handleSubmit();
    console.log(verified);
  };


  
  const [termsAccepted, setTermsAccepted] = useState(false); // State for checkbox

  const handleTermsChange = (e) => {
    setTermsAccepted(e.target.checked);
  };

  return (
    <div className={classes["main-container"]}>
      {/* <div className={classes["logo-align"]}><img src={union} alt="" /></div> */}
      <div className={`${classes.row_hieght} row`}>
        <div className={`${classes.col_img} col-md-7`}>
          {/* <img className={classes["left-img"]} src={leftImg} alt="" /> */}
          <div className={classes["left-block-header"]}>
           <div className="mt-5"><img src={union} alt="" /></div>
            {/* <div className={classes["heading"]}>Sign up</div> */}
            <div className={classes["sub-heading"]}>Unlock Your Future with MSM Unify!</div>
            <div className={classes["description"]}>
            Get expert support at every step — from free counseling to institutional admissions.
            </div>
          </div>
          <div className={classes["left-block-cards"]}>
          <img className="w-100" src={leftImage} alt="" />

          </div>
        </div>
        <div className={`${classes.right_col} col-md-5 white-back`}>

       
            
          <div className={classes["sign_up-box"]}>

          <div className={classes["signup-header"]}>
              <h1 className={classes["signup-title"]}>Sign Up</h1>
              <p className={classes["signup-description"]}>
                Sign up now and embark on your global education journey!
              </p>
            </div>

            <div className={`${classes.main_div}`}>
              <div className={`${classes.main_div}`}>
              <div className={currentStep === 1?`${classes.circle1}`:`${classes.selected_circle1}`}></div>
              <div className={`${classes.divideLIne1}`}></div>
              <div className={`${classes.stepText1}`}>Account</div>
              </div>
              <div className={`${classes.main_div}`}>
              <div className={currentStep === 3 || currentStep === 4 ?`${classes.selected_circle2}`:currentStep === 2?`${classes.focus_circle2}`:`${classes.circle2}`}></div>
              <div className={currentStep === 2 || currentStep === 3 || currentStep === 4 ?`${classes.selected_divideLIne2}`:`${classes.divideLIne2}`}></div>
              <div className={`${classes.stepText2}`}>Personal</div>
              
              </div>
              <div className={`${classes.main_div}`}>
              <div className={currentStep === 3 || currentStep === 4?`${classes.selected_divideLIne3}`:`${classes.divideLIne3}`}></div>
              <div className={currentStep === 3 || currentStep === 4?`${classes.selected_circle3}`:`${classes.circle3}`}></div>
              <div className={`${classes.stepText3}`}>Authentication</div>
              
              </div>
            </div>
            {/* {(currentStep != 1) && (
              <div title="back" onClick={handleBack} className={classes["back-btn"]}>
              <img className={classes["back-arrow-icon"]} src={backArrow} alt="" />
            </div>
            )} */}
            {/* <div className={classes.header}>
              <span>
                <img src={union} alt="" />
              </span>
            </div> */}

            <form>
              <div className={classes["form-section"]}>
                {/* step1 */}

                {currentStep === 1 && (
                  <div className={classes["form-content"]}>
                    <div className={classes["mat-form-field"]}>
                      {/* <label
                        htmlFor="exampleInputEmail1"
                        className={`${classes.label} form-label`}
                      >
                        Email
                      </label> */}
                      <input
                        onChange={changeHandler}
                        type="text"
                        name="email"
                        placeholder=""
                        value={form.email}
                        onBlur={changeHandler}
                        className={classes["mat-input"]}
                        id="exampleInputEmail1"
                        aria-describedby="emailHelp"
                      />
                      <label className={classes["mat-label"]}>Email</label>
                      {formErrors.email && (
                        <span className={classes.error}>
                          {formErrors.email}
                        </span>
                      )}
                    </div>
                    <div className={classes["mat-form-field"]}>
                      {/* <label
                        htmlFor="exampleInputPassword1"
                        className={`${classes.label} form-label`}
                      >
                        Password
                      </label> */}

                      <div className={classes["input-with-icon"]}>
                        <input
                          onChange={changeHandler}
                          onBlur={changeHandler}
                          type={passwordType}
                          placeholder=""
                          name="password"
                          value={form.password}
                          className={classes["mat-input"]}
                          id="exampleInputPassword1"
                        />
                        <label className={classes["mat-label"]}>Password</label>
                        {form.password && (
                          <div className={classes["icon-container"]}>
                            <span
                              className={classes["eyeicon"]}
                              onClick={viewPass}
                            >
                              <i
                                className={`fa ${visible ? "fa-eye" : "fa-eye-slash"
                                  }`}
                              />
                            </span>
                          </div>
                        )}
                      </div>

                      {formErrors.password && (
                        <span className={classes.error}>
                          {formErrors.password}
                        </span>
                      )}
                    </div>
                    <div className={classes["mat-form-field"]}>
                      {/* <label
                        htmlFor="exampleInputConfirmPassword"
                        className={`${classes.label} form-label`}
                      >
                        Confirm Password
                      </label> */}
                      <div className={classes["input-with-icon"]}>
                        <input
                          onChange={changeHandler}
                          onBlur={changeHandler}
                          type={confirmPasswordType}
                          placeholder=""
                          name="cpassword"
                          value={form.cpassword}
                          className={classes["mat-input"]}
                          id="exampleInputConfirmPassword"
                        />
                        <label className={classes["mat-label"]}> Confirm Password</label>
                        {form.cpassword && (
                          <div className={classes["icon-container"]}>
                            <span
                              className={classes["eyeicon"]}
                              onClick={viewConfirmPass}
                            >
                              <i
                                className={`fa ${visibleConfirm ? "fa-eye" : "fa-eye-slash"
                                  }`}
                              />
                            </span>
                          </div>
                        )}
                      </div>

                      {formErrors.cpassword && (
                        <span className={classes.error}>
                          {formErrors.cpassword}
                        </span>
                      )}
                    </div>

                    <div className={classes["password-validation"]}>
                      <div className={classes["validation-heading"]}>
                        Password must contain:
                      </div>

                      <ul className={`${classes["validation-item"]}m-0 px-3 row`}>
                        {!form.password ? (
                          <li style={{color: '#A6A6A6'}} className="col-md-6 col-sm-12 p-0 m-0">
                            <span style={{color: '#A6A6A6', fontSize: '12px', fontWeight:500}}>8 characters minimum</span>
                          </li>
                        ) : !passwordValidationErrors.minLength ? (
                          <li style={{ color: "#00A197" }} className="col-md-6 col-sm-12 p-0 m-0">
                            {/* <div className="row"> */}
                              <span className="col-12">
                              8 characters minimum
                              </span>
                              {/* <span className="col-3">
                                <i className="fa fa-check" />
                              </span> */}
                            {/* </div> */}
                          </li>
                        ) : (
                          <li style={{ color: "red" }} className="col-md-6 col-sm-12 p-0 m-0">
                            {/* <div className="row"> */}
                              <span className="col-12">
                              8 characters minimum
                              </span>
                              {/* <span className="col-3">
                                <i className="fa fa-close" />
                              </span> */}
                            {/* </div> */}
                          </li>
                        )}

                        {!form.password ? (
                          <li  style={{color: '#A6A6A6'}} className="col-md-6 col-sm-12 p-0 m-0">
                            <span style={{color: '#A6A6A6', fontSize: '12px', fontWeight:500}}>One special character</span>
                          </li>
                        ) : !passwordValidationErrors.specialChar ? (
                          <li style={{ color: "#00A197" }} className="col-md-6 col-sm-12 p-0 m-0">
                            {/* <div className="row"> */}
                              <span className="col-12">
                              One special character
                              </span>
                              {/* <span className="col-3">
                                <i className="fa fa-check" />
                              </span> */}
                            {/* </div> */}
                          </li>
                        ) : (
                          <li style={{ color: "red" }} className="col-md-6 col-sm-12 p-0 m-0">
                            {/* <div className="row"> */}
                              <span className="col-12">
                              One special character
                              </span>
                              {/* <span className="col-3">
                                <i className="fa fa-close" />
                              </span> */}
                            {/* </div> */}
                          </li>
                        )}

                        {!form.password ? (
                          <li  style={{color: '#A6A6A6'}} className="col-md-6 col-sm-12 p-0 m-0">
                            <span style={{color: '#A6A6A6', fontSize: '12px', fontWeight:500}}>One number</span>
                          </li>
                        ) : !passwordValidationErrors.number ? (
                          <li style={{ color: "#00A197" }} className="col-md-6 col-sm-12 p-0 m-0 ">
                            {/* <div className="row"> */}
                              <span className="col-12">One number</span>
                              {/* <span className="col-3">
                                <i className="fa fa-check" />
                              </span> */}
                            {/* </div> */}
                          </li>
                        ) : (
                          <li style={{ color: "red" }} className="col-md-6 col-sm-12 p-0 m-0">
                            {/* <div className="row"> */}
                              <span className="col-12">One number</span>
                              {/* <span className="col-3">
                                <i className="fa fa-close" />
                              </span> */}
                            {/* </div> */}
                          </li>
                        )}

                        {!form.password ? (
                          <li  style={{color: '#A6A6A6'}} className="col-md-6 col-sm-12 p-0 m-0">
                            <span style={{color: '#A6A6A6', fontSize: '12px', fontWeight:500}}>One uppercase letter</span>
                          </li>
                        ) : !passwordValidationErrors.uppercase ? (
                          <li style={{ color: "#00A197" }} className="col-md-6 col-sm-12 p-0 m-0">
                            {/* <div className="row"> */}
                              <span className="col-12">
                              One uppercase letter
                              </span>
                              {/* <span className="col-3">
                                <i className="fa fa-check" />
                              </span> */}
                            {/* </div> */}
                          </li>
                        ) : (
                          <li style={{ color: "red" }} className="col-md-6 col-sm-12 p-0 m-0">
                            {/* <div className="row"> */}
                              <span className="col-12">
                              One uppercase letter
                              </span>
                              {/* <span className="col-3">
                                <i className="fa fa-close" />
                              </span> */}
                            {/* </div> */}
                          </li>
                        )}
                      </ul>
                    </div>
                  </div>
                )}

                {/* step 2*/}

                {currentStep === 2 && (
                  <div className={classes["form-content"]}>
                    <div className="row">
                      <div className="col-md-6 col-sm-12 p-0">
                      <div className={classes["mat-form-field"]}>
                      {/* <label
                        htmlFor="exampleInputFirstName"
                        className={`${classes.label} form-label`}
                      >
                        First Name
                      </label> */}
                      <input
                        type="text"
                        placeholder=""
                        name="fname"
                        value={form.fname}
                        onChange={changeHandler}
                        onBlur={changeHandler}
                        className={classes["mat-input"]}
                        id="exampleInputFName"
                      />
                      <label className={classes["mat-label"]}>First Name</label>
                      {formErrors.fname && (
                        <span className={classes.error}>
                          {formErrors.fname}
                        </span>
                      )}
                    </div>
                      </div>
                     <div className={` ${classes.padding_remove} col-md-6 col-sm-12 `}>
                    <div className={classes["mat-form-field"]}>
                      {/* <label
                        htmlFor="exampleInputLastName"
                        className={`${classes.label} form-label`}
                      >
                        Last Name
                      </label> */}
                      <input
                        type="text"
                        placeholder=""
                        name="lname"
                        value={form.lname}
                        onChange={changeHandler}
                        onBlur={changeHandler}
                        className={classes["mat-input"]}
                        id="exampleInputLName"
                      />
                      <label className={classes["mat-label"]}>Last Name</label>
                      {formErrors.lname && (
                        <span className={classes.error}>
                          {formErrors.lname}
                        </span>
                      )}
                    </div>
                    </div>
                    <div className="col-md-6 col-sm-12 mt-4 p-0">
                    <div className="form-group">
                      <Form>
                        <InputGroup className={classes["contact-input-group"]}>
                          <Select
                            className={`${classes["country-code-dropdown"]} country-flag-block`}
                            options={countryCode}
                            getOptionLabel={(option) => `+${option.CountryCode} - ${option.CountryName}`}
                            getOptionValue={(option) => option.CountryCode}
                            onChange={(selectedOption) => handleCountrySelect(selectedOption)}
                            components={{ Option: CountryOption, SingleValue }}
                            placeholder="Country Code"
                            value={selectedCountry}
                            styles={{
                              indicatorSeparator: (base) => ({
                                ...base,
                                backgroundColor: 'transparent', // Remove the background color of the separator
                              }),
                              control: (base) => ({
                                ...base,
                                borderColor: 'transparent', // Remove border color
                                boxShadow: 'none', // Remove blue glow
                                borderRadius: '0px', // No border radius
                                minHeight: '40px',
                                '&:hover': {
                                  borderColor: 'transparent', // Ensure border remains transparent on hover
                                },
                                '&:focus': {
                                  outline: 'none', // Remove outline on focus
                                  borderColor: 'transparent', // Ensure border remains transparent on focus
                                },
                              }),
                              menu: (base) => ({
                                ...base,
                                width: '200%',
                                zIndex: 100,
                              }),
                              indicatorsContainer: (base) => ({
                                ...base,
                                padding: '0',
                                paddingRight: '25px',
                                height: '45px',
                              }),
                              dropdownIndicator: (base) => ({
                                ...base,
                                padding: '0',
                                color: "dark grey",
                                width: '18px',
                                height: '20px',
                                lineHeight: '40px',
                              }),
                              singleValue: (base) => ({
                                ...base,
                                display: 'flex',
                                alignItems: 'center', // Align center
                                lineHeight: '40px', // Adjust line height to reduce spacing
                              }),
                            }}

                          />
                          </InputGroup>
                      </Form>
                      </div>
                      </div>
                      <div className="col-md-6 col-sm-12 mt-4">
                      <div className={classes["mat-form-field"]}>
                        <input
                            className={classes["mat-input"]}
                            placeholder=""
                            name="contact"
                            value={form.contact}
                            onChange={changeHandler}
                            onBlur={changeHandler}
                          />
                          <label className={classes["mat-label"]}>Phone Number</label>
                        {formErrors.contact && (
                        <span className={classes.error}>{formErrors.contact}</span>
                        )}
                    </div>
                        </div>
                    </div>


                  


                    <div className={`${classes['floating-select-container']} form-group`}>
                    <select
                  name="gender"
                  value={form.gender || ""}
                  className="form-control custom-select"
                  onChange={changeHandler}
                  onFocus={handleFocus(setGenderOpen)}
                  onBlur={handleBlur(setGenderOpen)}
                  id="exampleInputContact"
                  placeholder="Gender"
                    >
                      <option value="" disabled></option> {/* Blank option */}
                      {GenderData.map((data, index) => (
                        <option key={index} value={data}>
                          {data}
                        </option>
                      ))}
                    </select>
                    <label className={form.gender ? `${classes.filled}` : `""`}>Select Gender</label>
                  </div>
                    <div className={classes["mat-form-field"]}>
                      {/* <label
                        htmlFor="exampleInputLastName"
                        className={`${classes.label} form-label`}
                      >
                        Birthday
                      </label> */}
                      <div className={classes.dropDownIconContainer}>
                        <input
                          type="date"
                          placeholder="Type Name Here..."
                          name="dob"
                          value={form.dob}
                          onChange={changeHandler}
                          onBlur={changeHandler}
                          className={classes["mat-input"]}
                          id="exampleInputDob"
                          max={getMaxDate()}
                        />
                         <label className={classes["mat-label"]}>Birthday</label>
                      </div>
                      {formErrors.dob && (
                        <span className={classes.error}>
                          {formErrors.dob}
                        </span>
                      )}
                    </div>
                  </div>
                )}

                {/* step 3 */}

                {currentStep === 3 && (
                  <>
                    <div className={classes["authorization-container"]}>
                      <div className="text-center">
                        <p className={classes["heading"]}>
                        We will send you a code to verify your account and to keep it secure.
                        </p>
                        <p className={classes["heading-sub"]}>Select one option below:</p>
                      </div>
                      <div className={classes["authorization-content"]}>
                        <div className={classes["authorization-option"]}>
                          <input
                            className={`${classes.radioInput}`}
                            type="radio"
                            id="email"
                            name="authorization"
                            value="email"
                            checked={authorizationMethod === "email"}
                            onChange={handleChange}
                          />
                          <label className="form-check-label" htmlFor="email">
                            <span>Email : </span>
                            <span>{maskEmail(form.email)}</span>
                          </label>
                        </div>
                        <div className={classes["authorization-option"]}>
                          <input
                            className={`${classes.radioInput}`}
                            type="radio"
                            id="phone"
                            name="authorization"
                            value="phone"
                            checked={otpVerificationPossible && authorizationMethod === "phone"}
                            onChange={handleChange}
                            disabled={!otpVerificationPossible}
                          />
                          <label
                            className={`${classes.phone_section} form-group form-check-label `}
                            htmlFor="phone"
                          >
                            <span>Phone : </span>
                            {/* <span className="form-group">
                              <input
                                type="tel"
                                className="form-control"
                                name="phoneNumber"
                                placeholder="Type phone number here..."
                                value={phoneNumber}
                                onChange={handlePhoneNumber}
                                disabled={true}
                              />
                              {formErrors.phoneNumber && (
                                <span className={classes.error}>
                                  {formErrors.phoneNumber}
                                </span>
                              )}
                            </span> */}
                            <span>{'XXX-XXX-' + phoneNumber?.slice(-4)}</span>
                          </label>
                        </div>
                      </div>
                    </div>
                  </>
                )}

                {currentStep === 4 && (
                  <>
                    <div className={classes["otp_section"]}>
                      <div className="text-center">
                        <p className={classes["heading"]}>
                        We’ve sent a 6-digit Code to your email (you@example.com).
                        </p>

                      </div>
                      <div>
                        <p
                          onClick={backOnAuthentication}
                          className={classes["change_auth"]}
                        >
                          Change Authentication Device
                        </p>
                      </div>
                      <p className={classes.hintText}>Please enter it below to continue.</p>
                      <div className={classes["otp_input"]}>
                        <OTPInput
                          inputStyle={invalidOtp ? invalidOtpStyle : inputStyle}
                          value={otp}
                          onChange={getOtp}
                          numInputs={6}
                          renderSeparator={<span></span>}
                          renderInput={(props) => (
                            <input
                              className={classes["otp_Input"]}
                              {...props}
                            />
                          )}
                        />
                      </div>
                      <div>
                        {invalidOtp && (
                          <p className={classes["timer"]}>
                            Wrong code. Please try again
                          </p>
                        )}
                        {otpSubmitted && (
                          <p className={classes["timer"]}>Success!</p>
                        )}
                      </div>
                      <div className={classes.alignment}>
                      <div>
                        {timeLeft > 0 ? (
                          <p className={classes["timer-1"]}>{timeLeft} seconds</p>
                        ) : <br />}
                      </div>
                      <div>
                        <button
                          onClick={resendOtp}
                          type="button"
                          disabled={timeLeft !== 0}
                          className={`${classes.primary_button_resend} `}
                        >
                          Re-Send Code
                        </button>
                      </div>
                      </div>

                    </div>
                  </>
                )}


                
                {/* Terms and Conditions Section */}
                {(currentStep === 1) && (
                <div className={classes["terms-section"]}>
                  <div className="form-check">
                    <input
                      type="checkbox"
                      id="termsCheckbox"
                      className="form-check-input"
                      checked={termsAccepted}
                      onChange={handleTermsChange}
                    />
                   
                  </div>
                  <div className="mt-1">
                  <label htmlFor="termsCheckbox" v className={classes["terms-section-label"]}>
                      <span> I have read and agree to the{" "}</span>
                      <span className={classes["msm-link"]}>
                        MSM Unify Terms
                      </span>
                    </label>
                  </div>
                </div>
                   )}

                <div className="mt-2">
                  <button
                    disabled={
                      (currentStep === 1 &&
                        (!form.email || !form.password || !form.cpassword || (passwordValidationErrors.minLength) || (passwordValidationErrors.specialChar) || (passwordValidationErrors.number) || (passwordValidationErrors.uppercase) || (form.password != form.cpassword))) ||
                      (currentStep === 2 && (!form.fname || !form.lname || !form.contact || !form.countryCode || !form.gender || !form.dob)) ||
                      (currentStep === 4 && otp?.length < 6) || Object.keys(formErrors).some(
                        (key) => formErrors[key])
                    }
                    className={`${classes.Sign_primary_button}`}
                    onClick={handleNext}
                  >
                   {currentStep === 1 
                      ? 'Get Started' 
                      : currentStep === 3 
                      ? 'Send Code' 
                      : currentStep === 4 
                      ? 'Verify Code' 
                      : 'Next'}
                  </button>
                  {(currentStep != 1) && (
                    <button title="back" onClick={handleBack} className={`${classes['go-back-button']} mt-3`}>Go Back</button>
                  )}

                </div>
                {(currentStep === 1) && (
                <div className={classes["get-started-section"]}>
                  <p className={classes["login-text"]}>
                    Already have an account?{" "}
                    <Link to="/sign-in" className={classes["login-link"]}>
                      Login
                    </Link>
                  </p>
                </div>
                   )}
                <div className="mt-4"></div>
              </div>
            </form>
          </div>
        </div>
      </div>
      <div>{isLoading && <Loader />}</div>
    </div>
  );
}

export default SignUp;
