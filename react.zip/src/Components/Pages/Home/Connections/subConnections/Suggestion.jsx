import React, { useState } from "react";
import classes from "./common.module.css";
import Suggestions from "../../User_Account/Connections/SubComponents/Suggestions";
import { Dropdown } from "react-bootstrap";
import dropdown from "../../../../../Assets/Logo/black-drop-down.svg";
import redsearch from "../../../../../Assets/Logo/red-search.svg";

const Suggestion = ({searchText, isSearchFlag, setIsSearchFlag}) => {

  const [selectedOption, setSelectedOption] = useState("1");
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const [isSort, setIsSort] = useState(false);

  const handleSelect = (eventKey) => {
    if(eventKey && selectedOption !== eventKey){
      setSelectedOption(eventKey);
      setIsSort(true);
    }
  };
  
  return (
    <div className="row mt-4">
      <div className={`${classes.containerForTab} col-md-12`}>
        <div className="d-flex justify-content-end mb-3">
           {/* <div className={classes.container1} style={{
                      border: "1px solid rgb(110, 110, 110)",
                      padding: "5px 15px",
                      borderRadius: "5px"
                    }}>
                        <img src={redsearch} className={classes.search} alt="search" />
                    <input
                      type="text"
                      style={{border: "none",
                         outline: "none"
                      }}
                      placeholder="Search by name"
                      className={classes.myinput}
                    />
                    </div> */}
          <div className={classes["sorting-drop-down-block"]}>
            <div className={classes["sorting-text"]}>Sort by:</div>
            <Dropdown
              onSelect={handleSelect}
              onToggle={(isOpen) => setIsDropdownOpen(isOpen)}
              className="drop-down-icon"
            >
              <Dropdown.Toggle
                variant="light"
                id="dropdown-basic"
                className={`${classes["drop-down-toggle"]}`}
              >
                {(selectedOption && selectedOption === "1") ? 'Recently Added' : (selectedOption && selectedOption === "2") ? 'A to Z' : 'Z to A'}
                {isDropdownOpen ? (
                  <img className={classes.dropdown} src={dropdown} alt="" />
                ) : (
                  <img className={classes.dropdown} src={dropdown} alt="" />
                )}
              </Dropdown.Toggle>

              <Dropdown.Menu className={classes["drp-down-items"]}>
                <Dropdown.Item eventKey="1">Recently Added</Dropdown.Item>
                <Dropdown.Item eventKey="2">A to Z</Dropdown.Item>
                <Dropdown.Item eventKey="3">Z to A</Dropdown.Item>
              </Dropdown.Menu>
            </Dropdown>
          </div>
        </div>
        <Suggestions searchInput={searchText} isSearch={isSearchFlag} setIsSearch={setIsSearchFlag} selectedSort={selectedOption} isSortingFlag={isSort} setSortingFlag={setIsSort} />
      </div>
    </div>
  )
    
};

export default Suggestion;
