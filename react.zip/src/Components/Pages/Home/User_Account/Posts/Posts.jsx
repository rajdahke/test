import React from "react";

function Posts(){
    return(
    
        <div>
           Posts
        </div>

    )
}
export default Posts;