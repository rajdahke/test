import React, { useEffect, useState, useRef } from "react";
import classes from "./User_Account.module.css";
import Marketing from "./Marketing/Marketing";
import avatarImage from "../../../../Assets/Images/backgroung_profile_image.jpg";
import profile_picture from "../../../../Assets/Images/profile_avatar.png";
import edit_profile from "../../../../Assets/Logo/edit_profile.svg";
import Posts from "../../../Common/Posts/Posts";
import Settings from "./Settings/Settings";
import Connections from "./Connections/Connections";
import About from "./About/About";
import Documents from "./Documents/Documents";
import Modal_Box from "../../../GlobleShared/Modal/Modal_Box";
import ProfileModel from "./Settings/Section/ProfileModel";
import Applications from "./Applications/Applications";
import ProfileService from "../../../../Services/ProfileService";
import Loader from "../../../GlobleShared/Loader/Loader";
import useLocalStorage from "../../../GlobleShared/CustomHooks/useLocalStorage";
import { toast } from "react-toastify";
import { useProfile } from "../../../Context/ProfileContext";
import ProfileUpdateModal from "../../../GlobleShared/Modal/ProfileUpdateModal/ProfileUpdateModal";

function UserAccount() {
  const [tab, setTab] = useState("About");
  const [modalIsVisible, setModalIsVisible] = useState(false);
  const [profileUpdateModalVisible, setProfileUpdateModalVisible] = useState(false);
  const [selectedHeading, setselectedHeading] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [rowData, setRowData] = useState(false);
  const [backgroundImage, setBackgroundImage] = useState('');
  const [profileImage1, setProfileImage1 ] = useState();
  const {profileImage, setProfileImage } = useProfile();
  const [studentDetails, setStudentDetails] = useState();
  const [connectionCount, setConnectionCount] = useState(0); 
  const [loggedinuserid, setLoggedinuserid] = useState(0); 
  const initial = useRef(null);
  const blobUrl = process.env.REACT_APP_URL_PATH;
  const dir=process.env.REACT_APP_BLOB_DIR_USER

  function hideModalhandler() {
    setModalIsVisible(false);
  }

  const [userDetail] = useLocalStorage('userDetail');
  const studentId = userDetail.refId;

  function showModalhandler(header) {
    setselectedHeading(header);
    setModalIsVisible(true);
  }

  const getAboutProfileInfo = () => {
    setIsLoading(true);
    ProfileService.getAboutProfileInfo(studentId).then((res) => {
      setRowData(res);
      if (res) {

        if (!res.DateOfBirth || !res.MobileNo || !res.Country) {
          setProfileUpdateModalVisible(true);
        }
        if (res && res.ProfileBGImage) {
          setBackgroundImage(blobUrl+(dir ? (dir +'/') :'') + res.ProfileBGImage);
        } else {
          setBackgroundImage(avatarImage);
        }
        if (res && res.ProfileImgPath) {
          setProfileImage1(blobUrl +(dir ? (dir +'/') :'')+ res.ProfileImgPath);
          setProfileImage(blobUrl +(dir ? (dir +'/') :'')+ res.ProfileImgPath);
        } else {
          setProfileImage1(profile_picture);
          setProfileImage(profile_picture);
        }
        setIsLoading(false);
      }
      setIsLoading(false);
    }).catch((error) => {
      console.log('error: ', error);
      setIsLoading(false);
    });
  }

  const getConnectionCount = (id) => {
    setIsLoading(true);
    ProfileService.getConnectionCount(id)
      .then((res) => {
        setConnectionCount(res);
        setIsLoading(false);
      })
      .catch((error) => {
        toast.error(error?.message);
        setIsLoading(false);
      });
  };

  useEffect(() => {
    if (!initial.current) {
      initial.current = true;
      getAboutProfileInfo();
      getStudentDetail(studentId);
      getConnectionCount(loggedinuserid);
    }
  // if(tab === "About"){
  //   setProfileUpdateModalVisible(true);
  // }
  }, [tab]);


  const getStudentDetail = () => {
    // setIsLoading(true);
    // StudentServices.getStudentDetail(studentId)
    //     .then((res) => { 
    //         setStudentDetails(res);
    //         if(res && res.ProfileBGImage){
    //           setBackgroundImage(blobUrl+res.ProfileBGImage);
    //         }else{
    //           setBackgroundImage(avatarImage);
    //         }
    //         //setIsLoading(false);
    //         if(res && res.ProfileImgPath){
    //           setProfileImage(blobUrl+res.ProfileImgPath);
    //         }else{
    //           setProfileImage(profile_picture);
    //         }
    //         setIsLoading(false);
    //     })
    //     .catch((error) => {
    //         toast.error(error?.message);
    //         setIsLoading(false);

    //     });
  }

  const handleImageChange = (image) => {
    // getStudentDetail();
    getAboutProfileInfo();
  };

  const handleProfileImageChange = (image) => {
    console.log("Updated Profile Image:", image);
    setProfileImage(image);
    setProfileImage1(image);
  };

  
  function hideProfileUpdateModal() {
    setProfileUpdateModalVisible(false);
  }

  function hideModalhandler() {
    setModalIsVisible(false);
  }

  function showModalhandler(header) {
    setselectedHeading(header);
    setModalIsVisible(true);
  }

  return (
    <div className={`${classes["user_account"]} row `}>
      {isLoading && <Loader></Loader>}
      <div className={` ${classes["user_account_section"]} col-md-9 col-lg-9`}>
      <div className={` ${classes["user_account_partSection"]}`}>
        <div className={classes["user_account_info"]}>
          <div className={classes["background_image"]}>
            <div className={classes["background_image_pic"]}>
              <img src={backgroundImage} alt="background-image " />
            </div>
            <div className={classes["profile_pic"]}>
              <span className={classes["user_profile_pic"]}>
                <img src={profileImage1} alt="User Profile_Picture" />
              </span>
              <span className={classes["edit_profile_icon"]} onClick={() => setModalIsVisible(true)}>
                <img src={edit_profile} alt="" />
              </span>
            </div>
          </div>
          {modalIsVisible && (
            <Modal_Box removePadding={true} onClose={hideModalhandler} onShow={showModalhandler} title={selectedHeading} isAboutModel={true}>
              <ProfileModel
                onProfileImageUpdated={handleImageChange}
                onClose={hideModalhandler}
              />
            </Modal_Box>
          )}
          <div className={`row ${classes["user_details"]}`}>
            <div className={`col-md-6 ${classes["user_personalDetails"]}`}>
              <p className={classes["name"]}>
                {(rowData.FirstName && rowData.LastName) ? (rowData.FirstName + ' ' + rowData.LastName) :  ' N/A'}
                <span>
                  {rowData.Gender === 'Female' ? ' (She/Her)' : rowData.Gender === 'Male' ? ' (He/His)' :  rowData.Gender === 'Others' ? ' (Others)' : ""}
                </span>
              </p>
              <p className={classes["email"]}>{rowData.Email ? rowData.Email : "N/A"}</p>
            </div>

            <div className={`col-md-6 ${classes["user_highlights"]}`}>
            <p>{rowData.TagLine ? rowData.TagLine : "No Tagline"}</p>
              <p>Highlights</p>
            </div>
          </div>

          <div className={classes["user_connections"]}>{connectionCount} Connections</div>

          {/* <div className={classes["section-line"]}>
            <hr />
          </div> */}

          <div className={classes["user_navigation"]}>
            <button
              className={tab === "About" ? classes["active_button"] : ""}
              onClick={() => setTab("About")}
            >
              About
            </button>
            <button
              className={tab === "Documents" ? classes["active_button"] : ""}
              onClick={() => setTab("Documents")}
            >
              Documents
            </button>
            <button
              className={tab === "Connections" ? classes["active_button"] : ""}
              onClick={() => setTab("Connections")}
            >
              Connections
            </button>
            {/* <button
              className={tab === "Application" ? classes["active_button"] : ""}
              onClick={() => setTab("Application")}
            >
              Applications
            </button> */}
            <button
              className={tab === "Posts" ? classes["active_button"] : ""}
              onClick={() => setTab("Posts")}
            >
              Posts
            </button>
            <button
              className={tab === "Settings" ? classes["active_button"] : ""}
              onClick={() => setTab("Settings")}
            >
              Settings
            </button>
          </div>
        </div>
        {tab === "About" && (
          <div>
            <About rowData={rowData} onUpdate={getAboutProfileInfo} />
          </div>
        )}

        {tab === "Posts" && (
          <div className={classes["posts_section"]}>
            <Posts showCrossIcon={true} />
          </div>
        )}
        {tab === "Settings" && (
          <div>
            <Settings />
          </div>
        )}
        {tab === "Connections" && (
          <div>
            <Connections />
          </div>
        )}
        {tab === "Documents" && (
          <div>
            <Documents />
          </div>
        )}
        {/* {tab === "Application" && (
          <div>
            <Applications /> //client requirement 
          </div>
        )} */}
      </div>
      </div>

      <div className={` ${classes["user_account_marketing"]} col-md-3 col-lg-3`}>
        <div className={classes["marketing_section"]}>
          <Marketing />
        </div>
      </div>
      {profileUpdateModalVisible && (
            <ProfileUpdateModal
              onClose={hideProfileUpdateModal}
              onUpdate={getAboutProfileInfo}
              onShow={profileUpdateModalVisible}
              profileData={rowData}
            />
          )}
    </div>
  );
}

export default UserAccount;