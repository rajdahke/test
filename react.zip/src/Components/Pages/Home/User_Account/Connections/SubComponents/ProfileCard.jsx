import React, { useEffect, useRef, useState } from "react";
import classes from "./Common.module.css";
import userPic from "../../.../../../../../../Assets/Images/backgroun2.png";
import userProfilePic from "../../.../../../../../../Assets/Images/man.png";
import plusIcon from "../../../../../../Assets/Logo/add-icon-red.svg";
import removeIcon from "../../../../../../Assets/Logo/Flat-Color.svg";
import useLocalStorage from "../../../../../GlobleShared/CustomHooks/useLocalStorage";
import union from "../../../../../../Assets/Logo/Union-contact.svg";
import removeaccount from "../../../../../../Assets/Logo/remove_account.svg";
const ProfileCard = ({
  ConnectButtonShow,
  buttonShow,
  handleAction,
  withdrawHandler,
  isInvitations,
  connectionsProfileDetails
}) => {

  const initialized = useRef(false);
  const blobUrl = process.env.REACT_APP_URL_PATH;
  const dir=process.env.REACT_APP_BLOB_DIR_USER
  const [profilePhoto, setProfilePhoto] = useState();
  const [backgroundPic, setBackgroundPic] = useState();
  const [userDetail] = useLocalStorage('userDetail');


  useEffect(() => {
    // if (!initialized.current) {
    //   initialized.current = true;
      if(connectionsProfileDetails?.profileImage){
        const getProfilePicPath = blobUrl+(dir ? (dir +'/') :'') + connectionsProfileDetails.profileImage;
        setProfilePhoto(getProfilePicPath);
        console.log('getProfilePicPath: ', getProfilePicPath);
      }
      if(connectionsProfileDetails?.profileBGImage){
        const getProfilePicPath = blobUrl+(dir ? (dir +'/') :'') + connectionsProfileDetails.profileBGImage;
        setBackgroundPic(getProfilePicPath);
      }
    // }
  }, [connectionsProfileDetails?.profileImage, connectionsProfileDetails?.profileBGImage]);

  const viewProfileSection = () => {
    // window.open('/member/profileView', '_blank');
    const userId = userDetail.user_id;
    let profileUrl = ``;
    if (userId === connectionsProfileDetails.senderUserId) {
      // profileUrl = `/member/profileView/${receiverUserId}`;
      profileUrl = `/member/profileView?userId=${connectionsProfileDetails.receiverUserId}&studentId=${connectionsProfileDetails.studentId}`;
    }
    else {
      // profileUrl = `/member/profileView/${senderUserId}`;
      profileUrl = `/member/profileView?userId=${connectionsProfileDetails.senderUserId}&studentId=${connectionsProfileDetails.studentId}`;
    }
    window.open(profileUrl, '_blank');
  }

  return (
    <>
      {!isInvitations && (<div className={classes.card}>
        <div className={classes.coverImage}>
          <span className={classes.backImage}>
            <img src={connectionsProfileDetails?.profileBGImage ? backgroundPic : userPic} />
          </span>
          <span className={classes.profileImage}>
            <img className={classes["profile-photo"]} src={connectionsProfileDetails?.profileImage ? profilePhoto : userProfilePic} />
          </span>
        </div>
        <div className={classes.content}>
          <div className={classes.content_info}>
            <div className={classes.name} title={connectionsProfileDetails?.displayName}><span className={classes["name-text"]} onClick={viewProfileSection}>{connectionsProfileDetails?.displayName ? connectionsProfileDetails.displayName : 'Not available'}</span></div>
            {/* <div className={classes.description}>{connectionsProfileDetails?.aboutUs ? connectionsProfileDetails.aboutUs : 'Not available'}</div> */}
          </div>
          <div className={classes.content_info}>
            <div className={classes.connectionCount}>
              {connectionsProfileDetails?.totalMutualCount} connections
            </div>
            <div className={classes["mutual-connections-profiles"]}>
              {connectionsProfileDetails?.mutualConnections && connectionsProfileDetails.mutualConnections.slice(0,3).map((mutualConnection, index) => (
                <img
                  key={index}
                  src={mutualConnection.profileImage ? blobUrl+(dir ? (dir +'/') :'')+ `${mutualConnection.profileImage}` : userProfilePic}
                  alt={mutualConnection.displayName}
                  className={classes.connectionImage}
                />
              ))}
            </div>
          </div>
        </div>
        <div>
          {buttonShow ? (
            <div className={classes.buttons}>
              {ConnectButtonShow ? <button className={classes.plus}  onClick={() => handleAction(connectionsProfileDetails.senderUserId, "Connect")}>
                <img src={union} alt="Connect"/> Connect
              </button> : <button className={classes.acceptBtn} onClick={() => handleAction(connectionsProfileDetails.userConnectionId, "Accept")}>Accept</button>}
              {!(ConnectButtonShow) && <span className={classes.dismissButton} onClick={() => handleAction(connectionsProfileDetails.userConnectionId, "Decline")}>Decline</span>}
            </div>
          ) : (
            <div className={classes.buttons}>
              <button className={classes.withdrawButton} onClick={() => withdrawHandler(connectionsProfileDetails.userConnectionId, 7)}> <img style={{height: "20px", marginRight:"7px"}} src={removeaccount} className={classes.removeaccount}/>Withdraw</button>
            </div>
          )}
        </div>
        {ConnectButtonShow && (
          <div className={classes["remove-suggestion"]}>
            <img onClick={() => handleAction(connectionsProfileDetails.senderUserId, "dismiss")} className={classes["remove-icon"]} src={removeIcon} alt="Remove" />
          </div>
        )}
      </div>)}
      {isInvitations && (
        <div className={classes.invitationCard}>
          <img
            src={profilePhoto ? profilePhoto : userProfilePic}
            alt="Profile"
            className={classes.invitationProfileImage}
          />
          <div className={classes.invitationInfo}>
            <div className={classes.invitationName} onClick={viewProfileSection}>
              {connectionsProfileDetails?.displayName || "Not available"}
            </div>
            <div className={classes.invitationAbout}>
              {connectionsProfileDetails?.aboutUs || "Not available"}
            </div>
          </div>
          <div className={classes.invitationActions}>
            <span
              className={classes.invitationIgnore}
              onClick={() => handleAction(connectionsProfileDetails.userConnectionId, "Decline")}
            >
              Ignore
            </span>
            <button
              className={classes.invitationAccept}
              onClick={() => handleAction(connectionsProfileDetails.userConnectionId, "Accept")}
            >
              Accept
            </button>
          </div>
        </div>
      )}
    </>
  );
};

export default ProfileCard;
