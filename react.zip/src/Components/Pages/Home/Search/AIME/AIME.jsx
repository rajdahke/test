import React, { useState } from "react";
import styles from './AIME.module.css'
import { Button, ButtonGroup } from "react-bootstrap";
import ZigZagStepper from "./ZigZagStepper/ZigZagStepper";
import Rating from "./Rating/Rating";
import Button_Group from "./Button_Group/Button_Group";
import SearchPageModal from "../../../../GlobleShared/Modal/SearchPageModal/SearchPageModal";
import infoIcon from '../../../../../Assets/Logo/info-icon.svg'
import Rank_Button_Group from "./Rank_Button_Group/Rank_Button_Group";
const modalData7={
    description:'Mutiny1 bowsprit crack Jennys tea cup rutters gibbet no prey, no pay tackle jury mast chase run a rig. Bring a spring upon her cable pink belay Spanish Main chase guns Letter of Marque hands cog aft fore. Scuttle carouser furl hearties ahoy main sheet Spanish Main long clothes pressgang fore.Knave spanker spyglass crack Jennys tea cup tender smartly bilged on her anchor quarter scuttle Yellow Jack. Buccaneer sloop chase salmagundi galleon spike heave down keel reef sails prow. Lad reef sails scuttle fathom draft yard Nelsons folly swab brig Arr.Yard weigh anchor run a rig nipper lad Sail ho carouser gaff code of conduct overhaul. Fathom plunder scuttle man-of-war hail-shot pink barque Nelsons folly swing the lead starboard. Rutters hornswaggle Jolly Roger parley Admiral of the Black killick Barbary Coast lee jury mast lass.Mutiny1 bowsprit crack Jennys tea cup rutters gibbet no prey, no pay tackle jury mast chase run a rig. Bring a spring upon her cable pink belay Spanish Main chase guns Letter of Marque hands cog aft fore. Scuttle carouser furl hearties ahoy main sheet Spanish Main long clothes pressgang fore.Knave spanker spyglass crack Jennys tea cup tender smartly bilged on her anchor quarter scuttle Yellow Jack. Buccaneer sloop chase salmagundi galleon spike heave down keel reef sails prow. Lad reef sails scuttle fathom draft yard Nelsons folly swab brig Arr.Yard weigh anchor run a rig nipper lad Sail ho carouser gaff code of conduct overhaul. Fathom plunder scuttle man-of-war hail-shot pink barque Nelsons folly swing the lead starboard. Rutters hornswaggle Jolly Roger parley Admiral of the Black killick Barbary Coast lee jury mast lass.Mutiny1 bowsprit crack Jennys tea cup rutters gibbet no prey, no pay tackle jury mast chase run a rig. Bring a spring upon her cable pink belay Spanish Main chase guns Letter of Marque hands cog aft fore. Scuttle carouser furl hearties ahoy main sheet Spanish Main long clothes pressgang fore.Knave spanker spyglass crack Jennys tea cup tender smartly bilged on her anchor quarter scuttle Yellow Jack. Buccaneer sloop chase salmagundi galleon spike heave down keel reef sails prow. Lad reef sails scuttle fathom draft yard Nelsons folly swab brig Arr.Yard weigh anchor run a rig nipper lad Sail ho carouser gaff code of conduct overhaul. Fathom plunder scuttle man-of-war hail-shot pink barque Nelsons folly swing the lead starboard. Rutters hornswaggle Jolly Roger parley Admiral of the Black killick Barbary Coast lee jury mast lass.',
}
const modalData8={
    description:'Mutiny2 bowsprit crack Jennys tea cup rutters gibbet no prey, no pay tackle jury mast chase run a rig. Bring a spring upon her cable pink belay Spanish Main chase guns Letter of Marque hands cog aft fore. Scuttle carouser furl hearties ahoy main sheet Spanish Main long clothes pressgang fore.Knave spanker spyglass crack Jennys tea cup tender smartly bilged on her anchor quarter scuttle Yellow Jack. Buccaneer sloop chase salmagundi galleon spike heave down keel reef sails prow. Lad reef sails scuttle fathom draft yard Nelsons folly swab brig Arr.Yard weigh anchor run a rig nipper lad Sail ho carouser gaff code of conduct overhaul. Fathom plunder scuttle man-of-war hail-shot pink barque Nelsons folly swing the lead starboard. Rutters hornswaggle Jolly Roger parley Admiral of the Black killick Barbary Coast lee jury mast lass.',
}
const modalData15={
    description:'Mutiny2 bowsprit crack Jennys tea cup rutters gibbet no prey, no pay tackle jury mast chase run a rig. Bring a spring upon her cable pink belay Spanish Main chase guns Letter of Marque hands cog aft fore. Scuttle carouser furl hearties ahoy main sheet Spanish Main long clothes pressgang fore.Knave spanker spyglass crack Jennys tea cup tender smartly bilged on her anchor quarter scuttle Yellow Jack. Buccaneer sloop chase salmagundi galleon spike heave down keel reef sails prow. Lad reef sails scuttle fathom draft yard Nelsons folly swab brig Arr.Yard weigh anchor run a rig nipper lad Sail ho carouser gaff code of conduct overhaul. Fathom plunder scuttle man-of-war hail-shot pink barque Nelsons folly swing the lead starboard. Rutters hornswaggle Jolly Roger parley Admiral of the Black killick Barbary Coast lee jury mast lass.',
}

const AIME = () => {

    const [stepIndex, setStepIndex] = useState(1);
    const [ratingValue, setratingValue] = useState(1);
    const [jobType, setJobType] = useState('');
    const [selectedCountry, setSelectedCountry] = useState(null);
    const [selectedProvince, setSelectedProvince] = useState(null);
    const [selectedCity, setSelectedCity] = useState(null);
    const [selectedWorkPlace, setSelectedWorkPlace] = useState(null);
    const [selectedStudyField, setSelectedStudyField] = useState(null);
    const [selectedSubField, setSelectedSubField] = useState(null);
    const [selectedKeyArea, setSelectedKeyArea] = useState(null);
    const [selectedJobProfile, setSelectedJobProfile] = useState(null);
    const [selectedOption, setSelectedOption] = useState(null);
    const [budgetValue, setbudgetValue] = useState(0);
    const [modalIsVisible, setModalIsVisible] = useState(false);

    const countries = ["Australia", "Canada", "Ireland", "New Zealand", "United Kingdom", "United States"];
    const provinces = ["British Columbia", "Alberta", "Saskatchewan", "Manitoba", "Ontario", "Quebec"];
    const cities = ["Victoria", "Vancouver", "Burnaby", "Surrey", "Kamloops", "Kelowna"];
    const workPlaces = ["My Country of Origin", "My Country of Study", "Other"];
    const studyFields = ["Natural Science", "Social Sciences", "Humanities", "Engineering & Tech", "Business & Management", "Other"];
    const subFields = ["General Management", "Strategic Management", "Operational Management", "HR Management", "Financial Management", "Other"];
    const keyArea = ["Financial Planning", "Budgeting", "Cash Flow Management", "Fianacial Analysis & Reporting", "Accounting & Auditing", "Other"];
    const jobProfiles = ["Public Accountant", "Certified Public Accountant", "Internal Auditor", "External Auditor", "Forensic Accountant", "Other"];
    const stepSixData = ["Growth","Salary", "Work-Life Balance", "Aligns to My Values", "Work Environment", "Potential Impact"];
    const handleselectOption = (option, type) => {
        if (type == 'Countries') {
            setSelectedCountry(option);
        }
        if (type == 'Provinces') {
            setSelectedProvince(option);
        }
        if (type == 'Cities') {
            setSelectedCity(option);
        }
        if (type == 'Work Places') {
            setSelectedWorkPlace(option);
        }
        if (type == 'Field of Study') {
            setSelectedStudyField(option);
        }
        if (type == 'Sub-Field') {
            setSelectedSubField(option);
        }
        if (type == 'Key Area') {
            setSelectedKeyArea(option);
        }
        if (type == 'Job Profile') {
            setSelectedJobProfile(option);
        }
        if (type == 'Rank') {
            setSelectedJobProfile(option);
        }
    };

    const getStepIndex = () => {
        let value = stepIndex + 1
        setStepIndex(value)
    }
    const ratingValuePass = (value) => {
        setratingValue(value)

    }
    const showModalhandler=()=>{
        setModalIsVisible(true);

    }
    const hideModalhandler=()=>{
        setModalIsVisible(false);

    }

    return (
        <>
            <div>
                <div>
                    { (stepIndex===7 || stepIndex===8 || stepIndex===15) && (
                        <div className={styles['info-icon-alignment']}>
                        <img src={infoIcon} alt='' onClick={showModalhandler}></img>
                    </div>
                    )}
                    
                    <ZigZagStepper stepper={stepIndex} />
                </div>

                <div className={styles['content-section']}>
                    <div>
                        {stepIndex == 1 && (
                            <div>
                                <div>
                                    <div className={styles['heading-text']}>
                                        What type of job do you have in mind?
                                    </div>
                                    <div className={styles['text-area-input']}>
                                        <textarea onChange={(e) => { setJobType(e.target.value) }} value={jobType} name="jobType"></textarea>
                                    </div>
                                </div>
                                <div className={styles['btn-position']}>
                                    <button onClick={getStepIndex} className="primary-button" disabled={!jobType}>Next</button>
                                </div>
                                <div className={styles['btn-position']}>
                                    <button className={styles['find-btn']} >Find Me A Job</button>
                                </div>

                            </div>
                        )}

                        {/* step-two */}
                        {stepIndex == 2 && (
                            <div className={styles["aime-form-block"]}>
                                <div className={styles["form-header"]}>
                                    <div className={styles["heading"]}>
                                        Where do you plan on studying?
                                    </div>
                                </div>
                                <div className={styles["form-body"]}>
                                    <Button_Group optionsList={countries} optionType="Countries" selectedValue={selectedCountry} selectOptionHandler={handleselectOption} />
                                </div>
                                <div className={styles["form-footer"]}>
                                    <div className={styles["button-section"]}>
                                        <button onClick={getStepIndex} className={`${styles["next-btn"]} primary-button`} disabled={!selectedCountry}>Next</button>
                                    </div>
                                </div>
                            </div>
                        )}

                        {/* step-three */}
                        {stepIndex == 3 && (
                            <div className={styles["aime-form-block"]}>
                                <div className={styles["form-header"]}>
                                    <div className={styles["heading"]}>
                                        Where do you plan on studying?
                                    </div>
                                </div>
                                <div className={styles["form-body"]}>
                                    <Button_Group optionsList={provinces} optionType="Provinces" selectedValue={selectedProvince} selectOptionHandler={handleselectOption} />
                                </div>
                                <div className={styles["form-footer"]}>
                                    <div className={styles["button-section"]}>
                                        <button onClick={getStepIndex} className={`${styles["next-btn"]} primary-button`} disabled={!selectedProvince}>Next</button>
                                    </div>
                                </div>
                            </div>
                        )}

                        {/* step-four */}
                        {stepIndex == 4 && (
                            <div className={styles["aime-form-block"]}>
                                <div className={styles["form-header"]}>
                                    <div className={styles["heading"]}>
                                        Where do you plan on studying?
                                    </div>
                                </div>
                                <div className={styles["form-body"]}>
                                    <Button_Group optionsList={cities} optionType="Cities" selectedValue={selectedCity} selectOptionHandler={handleselectOption} />
                                </div>
                                <div className={styles["form-footer"]}>
                                    <div className={styles["button-section"]}>
                                        <button onClick={getStepIndex} className={`${styles["next-btn"]} primary-button`} disabled={!selectedCity}>Next</button>
                                    </div>
                                </div>
                            </div>
                        )}

                        {/* step-five */}
                        {stepIndex == 5 && (
                            <div className={styles["aime-form-block"]}>
                                <div className={styles["form-header"]}>
                                    <div className={styles["heading"]}>
                                        Where do you plan to work after graduating?
                                    </div>
                                </div>
                                <div className={styles["form-body"]}>
                                    <Button_Group optionsList={workPlaces} optionType="Work Places" selectedValue={selectedWorkPlace} selectOptionHandler={handleselectOption} />
                                </div>
                                <div className={styles["form-footer"]}>
                                    <div className={styles["button-section"]}>
                                        <button onClick={getStepIndex} className={`${styles["next-btn"]} primary-button`} disabled={!selectedWorkPlace}>Next</button>
                                    </div>
                                </div>
                            </div>
                        )}

                        {stepIndex === 6 && (
                            <div className={styles["aime-form-block"]}>
                            <div className={styles["form-header"]}>
                                <div className={styles["heading"]}>
                                Rank the following from most important to least
                                </div>
                            </div>
                            <div className={styles["form-body"]}>
                                 <Rank_Button_Group optionsList={stepSixData} optionType="Ranks" selectedValue={selectedWorkPlace} selectOptionHandler={handleselectOption} />
                            </div>
                            <div className={styles["form-footer"]}>
                                <div className={styles["button-section"]}>
                                    <button onClick={getStepIndex} className={`${styles["next-btn"]} primary-button`} disabled={!selectedCountry}>Next</button>
                                </div>
                                <br/>
                                <div className={styles["button-section"]}>
                                    <p className={styles["skipBtn"]}>Skip</p>
                                </div>
                            </div>
                        </div>
                        )}
                        {stepIndex === 7 && (
                            <div className={styles["aime-form-block"]}>
                                <Rating nextRate={getStepIndex} getRate={ratingValuePass} heading='Analytical Thinking'></Rating>
                            </div>
                        )}
                        {stepIndex === 8 && (
                            <div className={styles["aime-form-block"]}>
                                <Rating nextRate={getStepIndex} getRate={ratingValuePass} heading='Integrity and Ethics'></Rating>
                            </div>
                        )}
                        {stepIndex === 9 && (
                            <div className={styles["aime-form-block"]}>
                                <Rating nextRate={getStepIndex} getRate={ratingValuePass} heading='Organization and Time Management'></Rating>
                            </div>
                        )}
                        {stepIndex === 10 && (
                            <div className={styles["aime-form-block"]}>
                                <Rating nextRate={getStepIndex} getRate={ratingValuePass} heading='Communication Skills'></Rating>
                            </div>
                        )}
                        {stepIndex === 11 && (
                            <div className={styles["aime-form-block"]}>
                                <Rating nextRate={getStepIndex} getRate={ratingValuePass} heading='Problem-Solving Abilities'></Rating>
                            </div>
                        )}
                        {stepIndex === 12 && (
                            <div className={styles["aime-form-block"]}>
                                <Rating nextRate={getStepIndex} getRate={ratingValuePass} heading='Adaptability'></Rating>
                            </div>
                        )}
                        {stepIndex === 13 && (
                            <div className={styles["aime-form-block"]}>
                                <Rating nextRate={getStepIndex} getRate={ratingValuePass} heading='Attention to Compliance'></Rating>
                            </div>
                        )}
                        {stepIndex === 14 && (
                            <div className={styles["aime-form-block"]}>
                                <Rating nextRate={getStepIndex} getRate={ratingValuePass} heading='Critical Thinking'></Rating>
                            </div>
                        )}
                        {stepIndex === 15 && (
                            <div className={styles["aime-form-block"]}>
                                <Rating nextRate={getStepIndex} getRate={ratingValuePass} heading='Client Focus'></Rating>
                            </div>
                        )}
                            {stepIndex === 16 && (
                            <div className={styles["aime-form-block"]}>
                                <div className={styles["form-header"]}>
                                    <div className={styles["heading"]}>
                                    Do you have a tuition budget in mind?
                                    </div>
                                    <div className={styles['sub-text']}>
                                        <p className="mb-0">We don’t mean to pry;
                                        </p>
                                    </div>
                                    <div className={styles['sub-text']}>
                                        <p className="mb-0">we just want to match you to the best suited programs</p>
                                    </div>
                                </div>
                                <div className={styles["form-body"]}>
                                <div className={styles['input-section']}>
                                <div>
                                <input value={budgetValue} onChange={(e)=>{setbudgetValue(e.target.value)}}  name="budget"></input>
                                </div>
                                <div>
                                    <select value='' >
                                        <option>$CAD</option>
                                        <option>$USD</option>
                                    </select>
                                    </div>
                                </div>
                                </div>
                                <div className={styles["form-footer"]}>
                                    <div className={styles["button-section"]}>
                                        <button onClick={getStepIndex} className={`${styles["next-btn"]} primary-button`} disabled={!selectedJobProfile}>Next</button>
                                    </div>
                                    <div className={styles["button-section"]}>
                                        <button onClick={getStepIndex} className={`${styles["next-btn"]} primary-button mt-2`}>Skip</button>
                                    </div>
                                </div>
                            </div>
                        )}

                        {stepIndex == 17 && (
                            <div className={styles["aime-form-block"]}>
                                <div className={styles["form-header"]}>
                                    <div className={styles["heading"]}>
                                        Select or Enter a Field of Study
                                    </div>
                                </div>
                                <div className={styles["form-body"]}>
                                    <Button_Group optionsList={studyFields} optionType="Field of Study" selectedValue={selectedStudyField} selectOptionHandler={handleselectOption} />
                                </div>
                                <div className={styles["form-footer"]}>
                                    <div className={styles["button-section"]}>
                                        <button onClick={getStepIndex} className={`${styles["next-btn"]} primary-button`} disabled={!selectedStudyField}>Next</button>
                                    </div>
                                </div>
                            </div>
                        )}

                        {stepIndex == 18 && (
                            <div className={styles["aime-form-block"]}>
                                <div className={styles["form-header"]}>
                                    <div className={styles["heading"]}>
                                        Select or Enter a Sub-Field of Study Business & Management
                                    </div>
                                </div>
                                <div className={styles["form-body"]}>
                                    <Button_Group optionsList={subFields} optionType="Sub-Field" selectedValue={selectedSubField} selectOptionHandler={handleselectOption} />
                                </div>
                                <div className={styles["form-footer"]}>
                                    <div className={styles["button-section"]}>
                                        <button onClick={getStepIndex} className={`${styles["next-btn"]} primary-button`} disabled={!selectedSubField}>Next</button>
                                    </div>
                                </div>
                            </div>
                        )}

                        {stepIndex == 19 && (
                            <div className={styles["aime-form-block"]}>
                                <div className={styles["form-header"]}>
                                    <div className={styles["heading"]}>
                                        Select or Enter a Key Area for Financial Management
                                    </div>
                                </div>
                                <div className={styles["form-body"]}>
                                    <Button_Group optionsList={keyArea} optionType="Key Area" selectedValue={selectedKeyArea} selectOptionHandler={handleselectOption} />
                                </div>
                                <div className={styles["form-footer"]}>
                                    <div className={styles["button-section"]}>
                                        <button onClick={getStepIndex} className={`${styles["next-btn"]} primary-button`} disabled={!selectedKeyArea}>Next</button>
                                    </div>
                                </div>
                            </div>
                        )}

                        {stepIndex == 20 && (
                            <div className={styles["aime-form-block"]}>
                                <div className={styles["form-header"]}>
                                    <div className={styles["heading"]}>
                                        Select or Enter a Job for Accounting & Auditing
                                    </div>
                                </div>
                                <div className={styles["form-body"]}>
                                    <Button_Group optionsList={jobProfiles} optionType="Job Profile" selectedValue={selectedJobProfile} selectOptionHandler={handleselectOption} />
                                </div>
                                <div className={styles["form-footer"]}>
                                    <div className={styles["button-section"]}>
                                        <button onClick={getStepIndex} className={`${styles["next-btn"]} primary-button`} disabled={!selectedJobProfile}>Next</button>
                                    </div>
                                </div>
                            </div>
                        )}
                    </div>
                </div>
            </div>
        { modalIsVisible && (
        <SearchPageModal onClose={hideModalhandler} onShow={showModalhandler} 
        data={stepIndex===7 ? modalData7 : stepIndex===8? modalData8 : modalData15 }>
        </SearchPageModal>
        )}
      
        </>
    );

}

export default AIME;