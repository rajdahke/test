
import classes from "./ProgramDetailPage.module.css";
import React, {useState,useEffect,useRef}from "react";
import program_details_image from "../../../../Assets/Images/program_details_image.png";
import heartIcon from "../../../../Assets/Logo/heartIcon.svg";
import LevelOfEducationIcon from "../../../../Assets/Logo/level of Education.svg";
import durationIcon from "../../../../Assets/Logo/duration.svg";
import costOfLivingIcon from "../../../../Assets/Logo/cost of living.svg";
import tutionFeeIcon from "../../../../Assets/Logo/Tuition Fee.svg";
import applicationFeeIcon from "../../../../Assets/Logo/Application fee.svg";
import downArrow from "../../../../Assets/Logo/down.arrow.svg";
import Loader from "../../../GlobleShared/Loader/Loader";
import {toast} from "react-toastify";
import { useBehaviorSubject } from "../../../GlobleShared/BehaviorSubject/BehaviorSubject";
import { useNavigate } from "react-router-dom";
import { useParams } from "react-router-dom";

import useLocalStorage from "../../../GlobleShared/CustomHooks/useLocalStorage";
import ProgramSearchService from "../../../../Services/ProgramSearchServices";
import ApplicationService from "../../../../Services/ApplicationServices";
import GuestUserModal from "../../../GlobleShared/Modal/GuestUserModal/GuestUserModal";
import dummyInst from '../../../../Assets/Images/dummy-inst.png'

function ProgramDetailPage() {


  const [userDetail] = useLocalStorage('userDetail');
  const studentId=userDetail?.refId
  const { programId } = useParams();
  const { institutionId } = useParams();
  const {selectedProgramTypeIds} = useParams();
  const {selectedCountryId} = useParams();
  const [programDetails, setProgramDetails] = useState(null);
  const [programContactList, setProgramContactList] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [otherProgramsList, setOtherProgramsList] = useState([]);
  const navigate = useNavigate();
  const [userDetails] = useLocalStorage("userDetails");
  const initial = useRef(null);
  const blobURL = process.env.REACT_APP_LOGO_PATH;
    
    const imageSrc = programDetails?.InstLogoPath
    ? blobURL + programDetails.InstLogoPath
    : program_details_image;


    const [isReadMore, setIsReadMore] = useState(true);
    const [start, setStart] = useState(0)
    const [loadmore, setLoadmore] = useState("Load more")
    const [currency, setCurrency] = useState()
    const [currencyExchangeRate, setCurrencyExchangeRate] = useState()

      const { isLoginUser } = useBehaviorSubject();
      const [guestuserFlag, setGuestuserFlag] = useState(false);
    
      const hideGuestModalhandler = () => {
        setGuestuserFlag(false);
      } 
    const handleApplyClick = (data) => {
        if (isLoginUser.isGuest) {
            setGuestuserFlag(true);
            return;
        }
        const programTypeId = programDetails.ProgramType === "On-Campus" ? 1 : 2;
          navigate("/member/application/add/"+programTypeId +"?studentId=" +studentId +'&programId='+ data?.ProgramId);
    };

   
    const handleMoreProgram = (programId) => {
        const programDetailUrl = `/member/programs/detailPage/${programId}`;
        window.open(programDetailUrl, '_blank');
      };
  
    const fetchProgramDetails = async (programId) => {
      setIsLoading(true);
      ProgramSearchService.getProgramDetailsById(programId)
      .then((res) => {
       setProgramDetails(res);
       searchProgramForAgentByFilterNew(programId, res?.InstitutionId, res?.InstCountryId)
        setIsLoading(false);
      })
      .catch((error) => {
        setIsLoading(false);
        toast.error(error?.message);
      });
    };
    // useEffect(() => {
    //   if (updateprogramId) {
    //     searchProgramForAgentByFilterNew(updateprogramId);
    //   }
    // }, [updateprogramId]);
  
    const searchProgramForAgentByFilterNew = (programId, InstitutionId, NationalityId) => {
        
      setIsLoading(true);
    
      const payload = 
        {
          Nationality: NationalityId,
          PartnerTypeId: "",
          param1: "",
          param2: "",
          InstitutionId: InstitutionId,
          ExceptProgramId: String(programId || ""),
          IsProgramLevelWise: true,
          ProgramType: 0,
        };
  
      ProgramSearchService.searchProgramForAgentByFilterNew(payload)
        .then((res) => {
          if (res){
            // debugger
            res.map((item) => {
                item.end = 4;
              });
            setOtherProgramsList(res);
            console.log(otherProgramsList);
            console.log(res);
          }
          setIsLoading(false);
        })
        .catch((error) => {
          setIsLoading(false);
          toast.error(error?.message);
        });
      };


  
    useEffect(() => {
      if(!initial.current){
        initial.current = true;
      fetchProgramDetails(programId);
      }
    }, [programId]);

  
  
    const getFeeDetail = (feeType, field) => {
        const fee = programDetails?.FeeDetail?.find((detail) => detail.FeeType === feeType);
        return fee ? fee[field] : "N/A";
      };
    
      const getConvertedFee = (feeType, field) => {
        const fee = programDetails?.FeeDetail?.find((detail) => detail.FeeType === feeType);
        if (!fee || !currencyExchangeRate || !currencyExchangeRate[programDetails?.ProgramCurrency]) return "N/A";
        const rate = currencyExchangeRate[programDetails?.ProgramCurrency]?.value;
        const amount = fee[field];
        return rate ? (amount / rate).toFixed(2) : "N/A";
      };

   
    const toggleReadMore = () => {
      setIsReadMore((prev) => !prev);
    };
  
    const loadMore = (programlevelid) => {
        setOtherProgramsList((prevList) =>
          prevList.map((item) => {
            if (item.ProgramLevelId === programlevelid) {
              const updatedEnd = item.end + 4;
              const isNoMoreResults = updatedEnd >= item.programs.length;
              return {
                ...item,
                end: updatedEnd,
                noMoreResults: isNoMoreResults,
              };
            }
            return item;
          })
        );
      };
      


    return (
        <>
         {guestuserFlag && (
        <GuestUserModal onClose={hideGuestModalhandler} onShow={guestuserFlag} />
      )}
      <div className={`${classes["new-design"]} ${classes["new-agent-design"]}`}>
        <div className={`${classes["grey-card"]} ${classes["bor-r-35"]}`}>
          <div className={`${classes["card"]} ${classes["box-shadow-none"]} ${classes["bor-r-35"]}`}>
            <div className={`${classes["card-body"]} p-0`}>
                <div className={classes.backColor}>
                <div className={`${classes["title-data"]} row`}>
                <div className="col-md-6 col-sm-12">
                <h4 className={`${classes["tittle"]}  mb-0"`}>
                  {programDetails?.ProgramName}
                </h4>
                <p className={` ${classes.subtext} my-auto ml-1`}>
                  By {programDetails?.InstName} 
                  {/* - {programDetails?.AgentType} */}
                </p>
                <div>
                <button
                type="button"
                className={`${classes["btn-agent-blue1"]}`}
                onClick={()=>handleApplyClick(programDetails)}>
                Apply
                </button>
                </div>
                </div>
           
                <div className="col-md-6 col-sm-12 text-end">
                   <img
                        src={`${blobURL+ programDetails?.InstLogoPath || ""}`}
                        className={classes["institution-detail-profile-img"]}
                        alt=""
                        />
                </div>
               </div>
              </div>

              <div className={classes.highBackcolor}>
                <div className={classes.higilht}>
                    <p>Highlights about program</p>
                </div>
                <div className={` ${classes.paddingHigh} row `}>
                <div className="col-md-4 col-sm-12">
                <label >Subject Requirements</label>
                    {programDetails?.SubjectRequirement?.length === 0 ? (
                        <p className={`${classes["prgbody1"]}`}>N/A</p>
                    ) : (
                        <ul>
                        {programDetails?.SubjectRequirement.map((subject, index) => (
                            <p key={index} className={`${classes["prgbody1"]}`}>
                            <li className={`${classes["prgli"]}`}>
                                {subject.ReqName} {subject.Score}
                            </li>
                            </p>
                        ))}
                        </ul>
                    )}
                </div>
                <div className="col-md-4 col-sm-12">
                 <label >Academic Requirements</label>
                    {programDetails?.AccadmicRequirement?.length === 0 ? (
                        <p className={`${classes["prgbody1"]}`}>N/A</p>
                    ) : (
                        <ul>
                        {programDetails?.AccadmicRequirement.map((academic, index) => (
                            <p key={index} className={`${classes["prgbody1"]}`}>
                            <li className={`${classes["prgli"]}`}>
                                {academic.ReqName} {academic.Score}
                            </li>
                            </p>
                        ))}
                        </ul>
                    )}
                </div>
                <div className="col-md-4 col-sm-12">
                <label >
                        English Language Requirements
                    </label>
                    {programDetails?.EnglishRequirement?.length === 0 ? (
                        <p className={`${classes["prgbody1"]}`}>Not Required</p>
                    ) : (
                        <ul>
                        {programDetails?.EnglishRequirement.map((eng, index) => (
                            <p key={index} className={classes["prgbody1"]}>
                            <li className={`${classes["prgli"]}`}>
                                {eng.ReqName} - overall score of {eng.Score}
                            </li>
                            </p>
                        ))}
                        </ul>
                    )}
                </div>
                </div>



              </div>
              <div className="row">
               <div className={`${classes["programDetails_left_section"]} col-md-8 d-flex align-items-stretch flex-column`}>
                    <label className={`${classes["prgTitle"]}`}>Program Overview</label>
                    <div className="mb-3">
                        <div
                        dangerouslySetInnerHTML={{ __html: programDetails?.Description }}
                        className={isReadMore ? classes["limitTextHeight"] : ""}
                        />
                        {programDetails?.Description?.length > 300 && (
                        <a onClick={toggleReadMore} className={`${classes["redTxt"]}`} style={{ lineHeight: "70px" }}>
                            {isReadMore ? "Read more" : "Read less"}
                        </a>
                        )}
                    </div>

                    <div className="d-flex bd-highlight prgbttm my-4">
                        <div className="pt-2 pr-2 pb-2 flex-fill bd-highlight">
                        {/* {programDetails?.EnglishRequirement?.length !== 0 && (
                            <button
                            type="button"
                            className={`${classes["btn-bor-blue"]}`}
                            onClick={() => console.log("Navigate to", programDetails?.ProgramId)}
                            >
                            Check students eligibility
                            </button>
                        )} */}
                        {/* {programDetails?.EnglishRequirement?.length === 0 &&
                            programDetails?.Inteks?.length > 0 && ( */}
                            {/* )} */}
                        </div>
                    </div>

                    {programDetails?.AdditionalRequirement?.length > 0 && (
                        <>
                        <label className={`${classes["prgTitle"]}`}>Additional Requirement</label>
                        {programDetails?.AdditionalRequirement.map((addreq, index) => (
                            <div key={index} className="d-flex">
                            <ul>
                                <li>
                                <span
                                    className={`${classes["additional_req"]} d-flex flex-wrap`}
                                    dangerouslySetInnerHTML={{ __html: addreq.AdditionalReq }}
                                />
                                </li>
                            </ul>
                            </div>
                        ))}
                        </>
                    )}

                    {programDetails?.DocumentRequirement?.length > 0 && (
                        <>
                        <label className={`${classes["prgTitle"]} mt-3`}>Documents Required</label>
                        <ul>
                            {programDetails?.DocumentRequirement.map((docreq, index) => (
                            <p key={index} className={`${classes["prgbody"]}`}>
                                <li className={classes.markerClass}>{docreq.DocumentName}</li>
                            </p>
                            ))}
                        </ul>
                        </>
                    )}
                    </div>
  
              <div className="col-md-4">
                <div className={`mb-3 ${classes["prgdtls"]}`}>
                    <div className="card text-center" style={{borderRadius:'10px', border:0, boxShadow: "none" , backgroundColor:"#FBF7F2"}}>
    
                    <div className={`card-body p-0 ${classes["card-body"]}`}>
                        <div className={`px-3 ${classes["body-content"]}`}>
                        {/* Application Fee */}
                        {programDetails?.FeeDetail?.length > 0 && (
                            <div className="d-flex bd-highlight">
                            <div className={`py-2 flex-fill bd-highlight ${classes["subInst1"]}`}>
                                <p className={`d-flex gap-1 ${classes["InstSubTitle"]} ${classes["InstSubText"]}`}>
                                Application Fee
                                </p>
                            </div>
                            <div className={`py-2 flex-fill bd-highlight ${classes["subInst2"]}`}>
                                <p className={`${classes["InstSubTitle"]} ${classes["InstSubTextValue"]}`}>
                                {programDetails?.ProgramCurrency === currency || !currencyExchangeRate ? (
                                    <>
                                     {programDetails?.ProgramCurrency}{" "}
                                    <span className={` ${classes[" text-gray"]} ${classes[""]}`}>
                                        {getFeeDetail("Application Fee", "FeeAmount")}
                                    </span>
                                    </>
                                ) : (
                                    <>
                                     {programDetails?.ProgramCurrency}{" "}
                                    <span className={` text-gray  ${classes[" text-gray"]} ${classes[""]}`}>
                                        {getConvertedFee("Application Fee", "FeeAmount")}
                                    </span>
                                    {getConvertedFee("Application Fee", "ActualFee")}
                                    </>
                                )}
                                </p>
                            </div>
                            </div>
                        )}

                        {/* Tuition Fee */}
                        {programDetails?.FeeDetail?.length > 0 && (
                            <div className="d-flex bd-highlight">
                            <div className={`py-2 flex-fill bd-highlight ${classes["subInst1"]}`}>
                                <p className={`d-flex gap-1  ${classes["InstSubTitle"]} ${classes["InstSubText"]}`}>
                                Tuition Fee ({getFeeDetail("Tuition Fee", "FeeBasis")})
                                </p>
                            </div>
                            <div className={`py-2 flex-fill bd-highlight ${classes["subInst2"]}`}>
                                <p className={`${classes["InstSubTitle"]} ${classes["InstSubTextValue"]}`}>
                                {programDetails?.ProgramCurrency === currency || !currencyExchangeRate ? (
                                    <>
                                    {programDetails?.ProgramCurrency}{" "}
                                    {getFeeDetail("Tuition Fee", "FeeAmount")}
                                    </>
                                ) : (
                                    getConvertedFee("Tuition Fee", "FeeAmount")
                                )}
                                </p>
                            </div>
                            </div>
                        )}

                        {/* Cost of Living */}
                        {programDetails?.InstCostofLiving_Year && (
                            <div className="d-flex bd-highlight">
                            <div className={`py-2 flex-fill bd-highlight ${classes["subInst1"]}`}>
                                <p className={`d-flex  gap-1  ${classes["InstSubTitle"]} ${classes["InstSubText"]}`}>
                                Cost of living per year
                                </p>
                            </div>
                            <div className={`py-2 flex-fill bd-highlight ${classes["subInst2"]}`}>
                                <p className={`${classes["InstSubTitle"]} ${classes["InstSubTextValue"]}`}>
                                {programDetails?.ProgramCurrency === currency || !currencyExchangeRate ? (
                                    `${programDetails?.ProgramCurrency} ${programDetails?.InstCostofLiving_Year || "N/A"}`
                                ) : (
                                    `${currency} ${(programDetails?.InstCostofLiving_Year /
                                    currencyExchangeRate[programDetails?.ProgramCurrency]?.value).toFixed(2)}`
                                )}
                                </p>
                            </div>
                            </div>
                        )}

                        {/* Duration */}
                        <div className="d-flex bd-highlight">
                            <div className={`py-2 flex-fill bd-highlight ${classes["subInst1"]}`}>
                            <p className={`d-flex gap-1  ${classes["InstSubTitle"]} ${classes["InstSubText"]}`}>
                                Duration
                            </p>
                            </div>
                            <div className={`py-2 flex-fill bd-highlight ${classes["subInst2"]}`}>
                            <p className={`${classes["InstSubTitle"]} ${classes["InstSubTextValue"]}`}>
                                {programDetails?.DurationTime || "N/A"}
                            </p>
                            </div>
                        </div>

                        {/* Level of Education */}
                        <div className="d-flex bd-highlight">
                            <div className={`py-2 flex-fill bd-highlight ${classes["subInst1"]}`}>
                            <p className={`d-flex  gap-1  ${classes["InstSubTitle"]} ${classes["InstSubText"]}`}>
                                Level of Education
                            </p>
                            </div>
                            <div className={`py-2 flex-fill bd-highlight ${classes["subInst2"]}`}>
                            <p className={`${classes["InstSubTitle"]} ${classes["InstSubTextValue"]}`}>
                                {programDetails?.LevelOfEducation || "N/A"}
                            </p>
                            </div>
                        </div>
                        </div>
                        <hr />
                       {/* Starting Date and Deadlines */}
                    <div className={`px-3 ${classes["starting-deadlines"]}`}>
                    <div className="row">
                        <div className="col-6">
                        <div className={`${classes["SubTitle"]} ${classes["InstSubTextValue1"]}`}>Starting Date</div>
                        </div>
                        <div className="col-6">
                        <div className={`${classes["SubTitle"]} ${classes["InstSubTextValue1"]} text-center`}>Submission Deadlines</div>
                        </div>
                    </div>
                    {programDetails?.Inteks?.length === 0 ? (
                        <div className="row">
                        <div className="col-12">
                            <p className={classes["InstSubTitle"]}>N/A</p>
                        </div>
                        </div>
                    ) : (
                        programDetails?.Inteks.map((item, index) => (
                        <div key={index} className="row my-1">
                            <div className="col-6">
                            <div className="d-flex align-items-center gap-1">
                                <div className={`${classes["InstSubTitle"]} ${classes["redSubTitle"]} text-red fz-10 text-nowrap`}>
                                {item?.IntakeName} -
                                </div>
                                <div className={classes["InstSubTitleStatus"]}>{item?.IntekStatus}</div>
                            </div>
                            </div>
                            <div className="col-6">
                            <div className={`${classes["InstSubTitle"]} ${classes["redSubTitle1"]} text-center  text-red fz-10`}>
                                {item?.SubmissionDeadline}
                            </div>
                            </div>
                        </div>
                        ))
                    )}
                    </div>
                    {programContactList?.length > 0 && (
                            <div className="card-footer" style={{ margin: 0 }}>
                                <div className="contactBox">
                                <h4 className="contactHeading">Contact Details</h4>
                                <div className="contact-list">
                                    <ol>
                                    {programContactList.map((contact, index) => (
                                        <li key={index}>
                                        <div className="contact-list-inner">
                                            <h5>{contact?.Name}</h5>
                                            <div className="row">
                                            <div className="col-12">
                                                <div className="d-flex text-break align-items-center">
                                                <img
                                                    src="assets/icons/email.svg"
                                                    alt=""
                                                    className="mr-2"
                                                    width="15"
                                                />
                                                <span className="text-truncate">
                                                    {contact?.Email}
                                                </span>
                                                </div>
                                            </div>
                                            </div>
                                        </div>
                                        </li>
                                    ))}
                                    </ol>
                                </div>
                                </div>
                            </div>
                            )}

                    </div>
                    </div>
                </div>
                </div>

              </div>

               {/* Program Offerings */}
                    {otherProgramsList?.length > 0 && (
                    <div>
                        <label className={`${classes["prgTitle"]} m-2`}>Program Offerings</label>
                        {otherProgramsList.map((item, index) => (
                        <div key={index}>
                            {item?.programs?.length > 0 && (
                            <label className={`${classes["prgLevel"]} m-2`}>{item?.ProgramLevel}</label>
                            )}
                            <div className="row">
                            {item?.programs?.slice(start, item?.end).map((program, idx) => (
                                <div key={idx} className="col-lg-4 col-md-6 col-sm-12 mb-4">
                                <div className={`card ${classes["crd"]}`}>
                                    <div>
                                        {!program?.Institution[0]?.InstLogoPath && (
                                        <img className={classes.imgeLogo}
                                        src={dummyInst}
                                         alt=""
                                        />                                                   
                                        )}
                                    {program?.Institution[0]?.InstLogoPath && (
                                        <img
                                        src={`${blobURL+program?.Institution[0]?.InstLogoPath}`}
                                        alt=""
                                     />                                                  
                                    )}
                                    </div>

                                    <p
                                    className={`${classes["instName"]} font-poppins text-56 text-truncate mb-0`}
                                        title={program?.Institution[0]?.InstName}
                                        >
                                        {program?.Institution[0]?.InstName}
                                        </p>
                                    <div className={`d-flex ${classes["icon-position"]}`}>
                                    <div
                                        className={`${classes["card-title"]} text-truncate mb-0`}
                                        title={program?.ProgramName}
                                    >
                                        {program?.ProgramName}
                                    </div>
                                    </div>
                                    <div
                                    className={`d-flex bd-highlight mainInst align-items-center px-2`}
                                    >
                                    {/* <div className={`${classes["institute-logo"]} pr-2 bd-highlight `}>
                                        <img
                                        src={`${blobURL+program?.Institution[0]?.InstLogoPath}`}
                                        alt={
                                            blobURL+program?.Institution[0]?.InstLogoPath ? "" : "avatar"
                                        }
                                        />
                                    </div> */}
                                    <div className={`${classes["institute-name"]} pl-2 bd-highlight `}>
                                        <p
                                        className={`${classes["subName"]} text-56 text-truncate`}
                                        title={`${program?.Institution[0]?.InstCity || ""}${
                                            program?.Institution[0]?.InstCity ? ", " : ""
                                        }${program?.Institution[0]?.InstCountry}`}
                                        >
                                        {program?.Institution[0]?.InstCity
                                            ? `${program?.Institution[0]?.InstCity}, `
                                            : ""}
                                        {program?.Institution[0]?.InstCountry}
                                        </p>
                                    </div>
                                    </div>
                                    <hr className="mb-2" />
                                    <div className="card-body">
                                    <div className={`d-flex bd-highlight  ${classes["subInst"]}`}>
                                        {program?.DurationTime && (
                                        <div className= {`px-2 pb-2 pt-0 flex-fill bd-highlight ${classes["subInst1"]}`}>
                                            <p className={classes["InstSubTitle"]}>Duration</p>
                                            <p className={classes["Instsub"]}>
                                            {program?.DurationTime}
                                            </p>
                                        </div>
                                        )}
                                        
                                        <div className= {`px-2 pb-2 pt-0 flex-fill bd-highlight ${classes["subInst2"]}`}>
                                            <p className={classes["InstSubTitle"]}>
                                            Level of Education
                                            </p>
                                            <p className={classes["Instsub"]}>
                                            {program?.ProgramLevel || 'NA'}
                                            </p>
                                        </div>
                                    </div>
                                    <div className={`d-flex bd-highlight  ${classes["subInst"]}`}>
                                        <div className={`px-2 pb-2 pt-0 flex-fill bd-highlight ${classes["subInst1"]}`}>
                                        <p className={classes["InstSubTitle"]}>Intakes</p>
                                        {program?.Intakes?.length > 0 ? (
                                            program?.Intakes.map((intake, i) => (
                                            <p key={i} className={classes["Instsub"]}>
                                                {`${intake.IntakeName} : ${intake.StatusName}`}
                                            </p>
                                            ))
                                        ) : (
                                            <p className={classes["Instsub"]}>
                                            No intake available
                                            </p>
                                        )}
                                        </div>
                                        {/* {program?.FeeDetail?.length > 0 && (
                                        <div className={`px-2 pb-2 pt-0 flex-fill bd-highlight ${classes["subInst2"]}`}>
                                            <p className={classes["InstSubTitle"]}>Fees</p>
                                            {program?.FeeDetail.map((feeItem, j) => (
                                            <p key={j} className={classes["Instsub"]}>
                                                {`${feeItem.FeeType} : ${program?.ProgramCurrency} ${feeItem.FeeAmount}`}
                                            </p>
                                            ))}
                                        </div>
                                        )} */}
                                        {program?.AverageProcessingDay && (
                                         
                                        <div className={`px-2 pb-2 pt-0 flex-fill bd-highlight ${classes["subInst2"]}`}>
                                        <p className={classes["InstSubTitle"]}>Processing Time</p>
                                        
                                        <div className= {`pt-0 bd-highlight  ${classes["subInst2"]}`}>
                                        <p className={classes["Instsub"]}>{program?.AverageProcessingDay + (program?.AverageProcessingDay!=0?" Day's":'')}</p>
                                    </div>
                                    </div>
                                    )}
                                         
                                    </div>
                                    {/* <div className={`d-flex mt-2 bd-highlight  ${classes["subInst"]}`}>
                                            <div className={`px-2 pb-2 pt-0 flex-fill bd-highlight ${classes["subInst1"]}`}>
                                            <p className={`text-56 ${classes["InstSubTitle"]}`}> {program?.ScholarShipAmtType !== null ? 'Scholarship' :'No Scholarship'}</p>
                                            {program?.ScholarShipAmtType === "0" && (
                                                <p className={` font-weight-bold mt-1 ${classes["waiverPercentage"]}`}>
                                                {program?.ScholarShipMinAmt} to {program?.ScholarShipMaxAmt}% Off
                                                </p>
                                            )} 
                                            {program?.ScholarShipAmtType === "1" && (
                                                <p className={` font-weight-bold mt-1 ${classes["waiverPercentage"]}`}>
                                                {program?.ProgramCurrency} {program?.ScholarShipMinAmt} to {program?.ProgramCurrency} {program?.ScholarShipMaxAmt}
                                                </p>
                                            )}
                                            </div>
                                        </div>
                                    {program?.WaiverPer && (
                                        <div className={`d-flex bd-highlight  ${classes["subInst"]}`}>
                                        <div className={`px-2 pb-2 pt-0 flex-fill bd-highlight ${classes["subInst1"]}`}>
                                            <p className={classes["InstSubTitle"]}>
                                            Application Fee Waivers
                                            </p>
                                            <span className={`${classes["strike-center"]} ${classes["text-gray"]}  ${classes["font-weight-bold"]} mx-1`}>
                                            {`${program?.ProgramCurrency} ${program?.ApplicationFee?.FeeAmount}`}
                                            </span>
                                            <span className={`${classes["text-green"]}  ${classes["font-weight-bold"]} mx-1`}>
                                            {`${program?.ProgramCurrency} ${program?.ApplicationFeeAfterWaiver}`}
                                            </span>
                                            <span className={` font-weight-bold mx-1 ${classes["waiverPercentage"]}`}>
                                            {`${program?.WaiverPer}% Off`}
                                            </span>
                                        </div>
                                        </div>
                                    )} */}
                                    </div>
                                    <hr className="mt-0" />
                                    <div
                                    className={` ${classes["card-footer"]} text-center pr-2 ${classes["footer"]}`}
                                    >
                                    {program?.Intakes?.length > 0 && (
                                        <button
                                        type="button"
                                        className={`${classes["btn-agent-blue-trans"]} mx-1`}
                                        onClick={()=>handleApplyClick(program)}
                                        >
                                        Apply Now
                                        </button>
                                    )}
                                    <button
                                        type="button"
                                        className={`${classes["btn-viewDetails"]} mx-1`}
                                        onClick={() => handleMoreProgram(program?.ProgramId)}
                                    >
                                        View Details
                                    </button>
      
                                    </div>
                                </div>
                                </div>
                            ))}
                            </div>

                            <div className="row no-gutters align-items-center mt10">
                                {item?.programs?.length > 0 && (
                                    <div className="col-12">
                                    <div className="d-flex justify-content-center">
                                        {item?.programs?.length > 4 && !item.noMoreResults && (
                                        <button
                                        type="button"
                                        className={`${classes["loadmore"]}`}
                                        id="loadMore"
                                        onClick={() => loadMore(item?.ProgramLevelId)}
                                        >
                                        {loadmore}
                                        <img  src={downArrow} alt="" className="mx-2" width="17" />
                                        </button>
                                        )}
                                    </div>
                                    </div>
                                )}
                                </div>
                        </div>
                        ))}
                    </div>
                    )}


            </div>
          </div>
        </div>
      </div>
      </>
    );
  };
  
  export default ProgramDetailPage;