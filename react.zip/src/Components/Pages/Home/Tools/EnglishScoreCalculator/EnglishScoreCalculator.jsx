import React from 'react'

const EnglishScoreCalculator = () => {
  return (
    <div>EnglishScoreCalculator</div>
  )
}

export default EnglishScoreCalculator