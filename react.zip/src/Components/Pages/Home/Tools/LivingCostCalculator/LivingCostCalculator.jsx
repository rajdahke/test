import React from 'react'

const LivingCostCalculator = () => {
  return (
    <div>LivingCostCalculator</div>
  )
}

export default LivingCostCalculator