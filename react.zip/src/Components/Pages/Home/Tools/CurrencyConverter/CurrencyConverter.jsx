import React from 'react'

const CurrencyConverter = () => {
  return (
    <div>CurrencyConverter</div>
  )
}

export default CurrencyConverter