import React from 'react'

const EducationCalculator = () => {
  return (
    <div>EducationCalculator</div>
  )
}

export default EducationCalculator