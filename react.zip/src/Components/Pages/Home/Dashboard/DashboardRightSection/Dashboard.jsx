import React from "react";
import { Outlet } from "react-router-dom";
import Header from "../../../../Common/Header/Header";

function Dashboard(){
    return(
        <>
        <div className="sticky-header"><Header /></div>
        <div className="main-page">
            <Outlet />
        </div>
        </>
    )
}
export default Dashboard;